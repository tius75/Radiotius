import TvHero from "@/components/tv/tv-hero";
import TvChannels from "@/components/tv/tv-channels";
export const metadata = {
  title: "TV Indonesia | Nusantara Stream",
  description: "Streaming TV Indonesia langsung dengan kualitas HD"
};
export default function TvPage() {
  return <main data-unique-id="392e4179-6aa3-4a83-a248-324bef61bf8b" data-file-name="app/tv/page.tsx">
      <TvHero />
      <TvChannels />
    </main>;
}