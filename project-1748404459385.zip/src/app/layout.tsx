import "@/styles/globals.css";
import React from "react";
import { Poppins } from "next/font/google";
import { type Metadata } from "next";
import { DevtoolsProvider } from 'creatr-devtools';
import Navbar from "@/components/layout/navbar";
import PlayerBar from "@/components/layout/player-bar";
const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-poppins'
});
export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1
};
export const metadata: Metadata = {
  title: {
    default: "Nusantara Stream",
    template: "%s | Nusantara Stream"
  },
  description: "Indonesian streaming platform featuring radio, TV, podcasts, and music",
  applicationName: "Nusantara Stream",
  keywords: ["Indonesia", "streaming", "radio", "TV", "podcast", "music", "Nusantara"],
  authors: [{
    name: "Nusantara Stream Team"
  }],
  creator: "Nusantara Stream Team",
  publisher: "Nusantara Stream Team",
  icons: {
    icon: [{
      url: "/favicon-16x16.png",
      sizes: "16x16",
      type: "image/png"
    }, {
      url: "/favicon-32x32.png",
      sizes: "32x32",
      type: "image/png"
    }, {
      url: "/favicon.ico",
      sizes: "48x48",
      type: "image/x-icon"
    }],
    apple: [{
      url: "/apple-touch-icon.png",
      sizes: "180x180",
      type: "image/png"
    }]
  },
  manifest: "/site.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Nusantara Stream"
  },
  formatDetection: {
    telephone: false
  }
};
export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return <html lang="id" className={`${poppins.variable} font-sans`} data-unique-id="d09e530f-f443-4ecb-9a7e-11c169dfcc6e" data-file-name="app/layout.tsx">
      <body data-unique-id="e101560d-112e-499a-8e40-1b608814a357" data-file-name="app/layout.tsx">
        <DevtoolsProvider>
          <div className="flex flex-col min-h-screen" data-unique-id="41a9022f-8aea-432a-b5d2-8e3e33273916" data-file-name="app/layout.tsx">
            <Navbar />
            <div className="flex-grow" data-unique-id="a55e4e85-a815-4ac8-9093-08755af03745" data-file-name="app/layout.tsx" data-dynamic-text="true">
              {children}
            </div>
            <PlayerBar />
          </div>
        </DevtoolsProvider>
      </body>
    </html>;
}