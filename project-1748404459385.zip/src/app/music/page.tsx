import MusicHero from "@/components/music/music-hero";
import MusicPlayer from "@/components/music/music-player";
import PlaylistSection from "@/components/music/playlist-section";
export const metadata = {
  title: "Music Player | Nusantara Stream",
  description: "Putar file musik FLAC, MP3, WAV, dan 32-bit audio dari penyimpanan internal"
};
export default function MusicPage() {
  return <main data-unique-id="2e839d31-7457-4b5d-99e7-f09ea28b852f" data-file-name="app/music/page.tsx">
      <MusicHero />
      <MusicPlayer />
      <PlaylistSection />
    </main>;
}