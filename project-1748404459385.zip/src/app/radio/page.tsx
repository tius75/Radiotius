import RadioDirectory from "@/components/radio/radio-directory";
import RadioHero from "@/components/radio/radio-hero";
export const metadata = {
  title: "Radio Indonesia | Nusantara Stream",
  description: "Nikmati streaming radio dari seluruh Indonesia dengan kualitas audio terbaik"
};
export default function RadioPage() {
  return <main data-unique-id="48ebce57-8900-4fcf-8843-1f8c7f634dfd" data-file-name="app/radio/page.tsx">
      <RadioHero />
      <RadioDirectory />
    </main>;
}