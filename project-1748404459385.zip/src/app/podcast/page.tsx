import PodcastHero from "@/components/podcast/podcast-hero";
import PodcastList from "@/components/podcast/podcast-list";
import PopularPodcasts from "@/components/podcast/popular-podcasts";
export const metadata = {
  title: "Podcast | Nusantara Stream",
  description: "Dengarkan podcast terbaik dari Indonesia dan seluruh dunia"
};
export default function PodcastPage() {
  return <main data-unique-id="5f726463-48bd-40e5-99b7-e8a90f819720" data-file-name="app/podcast/page.tsx">
      <PodcastHero />
      <PopularPodcasts />
      <PodcastList />
    </main>;
}