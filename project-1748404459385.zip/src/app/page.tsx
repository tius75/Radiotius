'use client';

import HeroSection from "@/components/home/hero-section";
import FeaturesSection from "@/components/home/features-section";
import PopularSection from "@/components/home/popular-section";
export default function HomePage() {
  return <main className="min-h-screen flex flex-col" data-unique-id="ff1c827d-2e12-4357-af6c-472311775c99" data-file-name="app/page.tsx">
      <HeroSection />
      <FeaturesSection />
      <PopularSection />
    </main>;
}