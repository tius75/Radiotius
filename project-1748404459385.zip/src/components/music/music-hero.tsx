'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Music, FileAudio } from 'lucide-react';
export default function MusicHero() {
  return <section className="py-16 bg-accent/20" data-unique-id="914a4ec3-6486-4e7d-ab85-3b5808bc3aab" data-file-name="components/music/music-hero.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="6ea54cee-95c6-4663-a24a-9aea6074336e" data-file-name="components/music/music-hero.tsx">
        <motion.div initial={{
        opacity: 0,
        y: 20
      }} animate={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.5
      }} className="max-w-3xl" data-unique-id="d68c3533-ae0f-44b8-8282-8dc746866bf6" data-file-name="components/music/music-hero.tsx">
          <div className="inline-flex items-center gap-2 bg-accent px-4 py-1.5 rounded-full text-sm font-medium mb-4" data-unique-id="678f6245-8c62-4a2d-bd08-c72ce96560cb" data-file-name="components/music/music-hero.tsx">
            <Music className="h-4 w-4 text-chart-4" />
            <span data-unique-id="c84ff440-8d98-421a-b363-ffee4139a63e" data-file-name="components/music/music-hero.tsx"><span className="editable-text" data-unique-id="b541d676-d829-4791-8bbf-40e75473e767" data-file-name="components/music/music-hero.tsx">Music Player</span></span>
          </div>
          
          <h1 className="text-4xl font-bold mb-4" data-unique-id="23582992-6b55-4c4c-a681-3c64ded4e6c3" data-file-name="components/music/music-hero.tsx"><span className="editable-text" data-unique-id="e9a221e1-783c-426f-bfb3-ae09caba1e98" data-file-name="components/music/music-hero.tsx">
            Musik 
            </span><span className="bg-gradient-to-r from-chart-4 to-chart-5 bg-clip-text text-transparent" data-unique-id="69353fd8-be80-4d42-88d7-c61320665a6d" data-file-name="components/music/music-hero.tsx"><span className="editable-text" data-unique-id="01a18fbd-ca22-4e73-a9f8-ba9c349b3997" data-file-name="components/music/music-hero.tsx"> Lokal</span></span><span className="editable-text" data-unique-id="6852f307-1e1a-434a-9102-0992258682ab" data-file-name="components/music/music-hero.tsx"> dari Penyimpanan Anda
          </span></h1>
          
          <p className="text-muted-foreground text-lg mb-8" data-unique-id="b186d91c-9763-4e92-b630-81305196dbe1" data-file-name="components/music/music-hero.tsx"><span className="editable-text" data-unique-id="92dcc63e-5547-44ed-ab79-c1879995c635" data-file-name="components/music/music-hero.tsx">
            Putar file musik FLAC, MP3, WAV, dan audio 32-bit dari penyimpanan internal Anda.
            Nikmati kualitas audio terbaik dengan fitur playlist yang lengkap.
          </span></p>
          
          <div className="bg-card border border-border rounded-xl p-6" data-unique-id="b0359185-f50f-4b7c-8514-3499aa86f4e2" data-file-name="components/music/music-hero.tsx">
            <div className="flex flex-col md:flex-row gap-4 items-center" data-unique-id="71894a4c-76f2-4c8d-94e2-565f838984e3" data-file-name="components/music/music-hero.tsx">
              <div className="bg-accent/50 rounded-full p-6" data-unique-id="84b149e3-53e3-4907-959c-b6d016aca410" data-file-name="components/music/music-hero.tsx">
                <FileAudio className="h-8 w-8 text-chart-4" />
              </div>
              
              <div data-unique-id="371cd4e7-b8a1-490d-9ecf-45719a0aa21a" data-file-name="components/music/music-hero.tsx">
                <h3 className="text-xl font-medium mb-2" data-unique-id="511b64f4-f4ce-4e6b-ac35-ab95688de33d" data-file-name="components/music/music-hero.tsx"><span className="editable-text" data-unique-id="c035979e-d5b9-486c-b14f-8657e214bfe9" data-file-name="components/music/music-hero.tsx">Unggah File Musik Anda</span></h3>
                <p className="text-muted-foreground mb-4" data-unique-id="f88c20da-50d5-4343-bfc7-37362a039203" data-file-name="components/music/music-hero.tsx"><span className="editable-text" data-unique-id="b0a87b01-7fb4-4d14-b6c2-ce17a2fbc6cb" data-file-name="components/music/music-hero.tsx">
                  Format yang didukung: FLAC, MP3, WAV, dan 32-bit audio
                </span></p>
                <label className="px-5 py-2.5 bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity inline-block cursor-pointer" data-unique-id="e2ed389b-f3f0-4447-970d-1f45f9a82e09" data-file-name="components/music/music-hero.tsx">
                  <input type="file" multiple accept=".mp3,.flac,.wav" className="hidden" onChange={e => {
                  // In a real implementation, we would handle the files here
                  // But for this demo, we'll just show an alert
                  alert('File upload functionality would be implemented in a real app!');
                }} data-unique-id="1ad619db-023e-4979-ac90-0825fea7b5fc" data-file-name="components/music/music-hero.tsx" /><span className="editable-text" data-unique-id="9b6c5bd7-33f9-4acf-8661-1933b213334a" data-file-name="components/music/music-hero.tsx">
                  Pilih File Musik
                </span></label>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>;
}