'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { ListMusic, Plus, PlayCircle, MoreHorizontal } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function PlaylistSection() {
  const {
    playlists,
    createPlaylist
  } = usePlayerStore();
  const [newPlaylistName, setNewPlaylistName] = React.useState('');
  const [isCreating, setIsCreating] = React.useState(false);
  const handleCreatePlaylist = () => {
    if (newPlaylistName.trim()) {
      createPlaylist(newPlaylistName.trim());
      setNewPlaylistName('');
      setIsCreating(false);
    }
  };

  // Sample playlists if none exist in the store
  const displayPlaylists = playlists.length > 0 ? playlists : [{
    id: 'sample-1',
    name: 'Favorit Saya',
    tracks: [{
      id: 'track-1',
      title: 'Indonesia Raya',
      artist: 'W.R. Soepratman',
      type: 'music' as const,
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4'
    }, {
      id: 'track-2',
      title: 'Tanah Airku',
      artist: 'Ismail Marzuki',
      type: 'music' as const,
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4'
    }]
  }, {
    id: 'sample-2',
    name: 'Lagu Daerah',
    tracks: [{
      id: 'track-3',
      title: 'Ampar-Ampar Pisang',
      artist: 'Traditional',
      type: 'music' as const,
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4'
    }, {
      id: 'track-4',
      title: 'Yamko Rambe Yamko',
      artist: 'Traditional',
      type: 'music' as const,
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4'
    }]
  }];
  return <section className="py-16 bg-muted/50" data-unique-id="91fee448-eada-4fc8-8354-b2d6b5dafa45" data-file-name="components/music/playlist-section.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="0e7c3dfe-3294-420d-ad08-9fc2270d74fc" data-file-name="components/music/playlist-section.tsx">
        <div className="flex items-center justify-between mb-8" data-unique-id="0a4a4648-38fb-409c-b0f7-24b736952b56" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true">
          <div data-unique-id="e3f2f6cb-712e-4f5e-96ff-af8635b5f6c4" data-file-name="components/music/playlist-section.tsx">
            <h2 className="text-2xl font-semibold mb-2" data-unique-id="34c67611-ff6c-4e03-8dee-221d740b0eae" data-file-name="components/music/playlist-section.tsx"><span className="editable-text" data-unique-id="2bf2a602-41b8-4dc7-8058-0b003ad6eaca" data-file-name="components/music/playlist-section.tsx">Playlist</span></h2>
            <p className="text-muted-foreground" data-unique-id="0fd67ef7-a6d5-4e09-8ebb-ff4c15df56fc" data-file-name="components/music/playlist-section.tsx"><span className="editable-text" data-unique-id="0cb1a068-fbd6-48c3-9ad6-4aeaf37d3e64" data-file-name="components/music/playlist-section.tsx">Kelola koleksi musik favorit Anda</span></p>
          </div>
          
          {!isCreating ? <button onClick={() => setIsCreating(true)} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity" data-unique-id="4f8c558d-ecfe-4a5b-b868-d849bdd2c68e" data-file-name="components/music/playlist-section.tsx">
              <Plus className="h-4 w-4" />
              <span data-unique-id="5cc67c4d-6872-4944-9398-e38666badbbf" data-file-name="components/music/playlist-section.tsx"><span className="editable-text" data-unique-id="3a108408-6ed8-4d0e-8d37-f94c9e9ae014" data-file-name="components/music/playlist-section.tsx">Buat Playlist</span></span>
            </button> : <div className="flex items-center gap-2" data-unique-id="1e90cac4-eb70-4ad6-a323-a5d72410af5e" data-file-name="components/music/playlist-section.tsx">
              <input type="text" placeholder="Nama playlist" value={newPlaylistName} onChange={e => setNewPlaylistName(e.target.value)} className="px-3 py-2 bg-card border border-border rounded-md" autoFocus data-unique-id="46007d0a-14b3-4f2f-a7ac-a27159f446b1" data-file-name="components/music/playlist-section.tsx" />
              <button onClick={handleCreatePlaylist} disabled={!newPlaylistName.trim()} className="px-4 py-2 bg-primary text-primary-foreground rounded-md disabled:opacity-50" data-unique-id="561d59b4-b989-4da0-8242-d6df28035ae8" data-file-name="components/music/playlist-section.tsx"><span className="editable-text" data-unique-id="46bbd7d3-716b-4f2d-8a7d-512132eb8208" data-file-name="components/music/playlist-section.tsx">
                Simpan
              </span></button>
              <button onClick={() => {
            setIsCreating(false);
            setNewPlaylistName('');
          }} className="px-4 py-2 bg-accent text-accent-foreground rounded-md" data-unique-id="08fa3f13-9c87-49be-81ad-3e0226e3b93d" data-file-name="components/music/playlist-section.tsx"><span className="editable-text" data-unique-id="dfa4245c-48cf-437c-b63e-352a14702c07" data-file-name="components/music/playlist-section.tsx">
                Batal
              </span></button>
            </div>}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-unique-id="73828308-1143-4a05-9462-917a9d805639" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true">
          {displayPlaylists.map((playlist, index) => <motion.div key={playlist.id} initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          delay: index * 0.1
        }} className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow" data-unique-id="3f6002fd-69bb-4666-ae4c-b3486df2b67c" data-file-name="components/music/playlist-section.tsx">
              <div className="relative h-40 bg-accent/50 flex items-center justify-center" data-unique-id="2a12dd78-7ea2-4be3-aef6-a964d076bc1a" data-file-name="components/music/playlist-section.tsx">
                <div className="absolute inset-0 flex items-center justify-center" data-unique-id="c6719046-d596-4d94-91af-b618b7a20638" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true">
                  {playlist.tracks.length > 0 ? <div className="grid grid-cols-2 gap-1 w-full h-full" data-unique-id="1543f461-f29c-4dcf-bdbd-e70ea2e4bcd8" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true">
                      {playlist.tracks.slice(0, 4).map((track, idx) => <div key={idx} className="bg-accent flex items-center justify-center" data-unique-id="f478703b-36d9-4044-be1b-eae64c42e535" data-file-name="components/music/playlist-section.tsx">
                          <ListMusic className="h-6 w-6 text-muted-foreground" data-unique-id="87ece8ed-7c2d-4831-9446-6b6bce84e277" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true" />
                        </div>)}
                    </div> : <ListMusic className="h-12 w-12 text-muted-foreground" data-unique-id="0ae324d2-30b0-4a3c-a065-ac8394900340" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true" />}
                </div>
                
                <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center" data-unique-id="5190fc2f-73c1-4eaa-a699-22209d5a8e4b" data-file-name="components/music/playlist-section.tsx">
                  <button className="h-12 w-12 rounded-full bg-primary flex items-center justify-center" data-unique-id="7d924c38-7613-411f-b6f7-6ae38d1d1006" data-file-name="components/music/playlist-section.tsx">
                    <PlayCircle className="h-6 w-6 text-primary-foreground" data-unique-id="5b0e9cef-b46b-45ab-9a97-65f1894f9305" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true" />
                  </button>
                </div>
              </div>
              
              <div className="p-4" data-unique-id="352027ce-c094-4d72-aac9-461a27df52bf" data-file-name="components/music/playlist-section.tsx">
                <div className="flex justify-between items-center" data-unique-id="9e97cc7e-0d93-445c-b7a6-c7782e5a1caa" data-file-name="components/music/playlist-section.tsx">
                  <h3 className="font-medium truncate" data-unique-id="fb9ad55b-d67c-4a9e-9871-c27d4a40488d" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true">{playlist.name}</h3>
                  <button className="text-muted-foreground hover:text-foreground" data-unique-id="94bff608-9779-4816-815f-64a7ab548bc7" data-file-name="components/music/playlist-section.tsx">
                    <MoreHorizontal className="h-5 w-5" data-unique-id="11cf1d9a-316a-475b-aa37-60ba42c0457c" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true" />
                  </button>
                </div>
                <p className="text-sm text-muted-foreground mt-1" data-unique-id="d0a9b259-13f4-4db0-ad6d-5d0d34de8dd0" data-file-name="components/music/playlist-section.tsx" data-dynamic-text="true">
                  {playlist.tracks.length}<span className="editable-text" data-unique-id="1a98693d-307a-4139-93c7-633b37a0a454" data-file-name="components/music/playlist-section.tsx"> lagu
                </span></p>
              </div>
            </motion.div>)}
        </div>
      </div>
    </section>;
}