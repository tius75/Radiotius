'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Play, Pause, SkipBack, SkipForward, Volume2, Share2 } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function MusicPlayer() {
  // In a real app, we'd load these from local storage or context
  const sampleTracks = [{
    id: 'local-1',
    title: 'Tanah Airku',
    artist: 'Ismail Marzuki',
    duration: 240,
    // in seconds
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'music' as const
  }, {
    id: 'local-2',
    title: 'Indonesia Pusaka',
    artist: 'Ismail Marzuki',
    duration: 198,
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'music' as const
  }, {
    id: 'local-3',
    title: 'Rayuan Pulau Kelapa',
    artist: 'Ismail Marzuki',
    duration: 220,
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'music' as const
  }, {
    id: 'local-4',
    title: 'Halo-Halo Bandung',
    artist: 'Ismail Marzuki',
    duration: 175,
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'music' as const
  }];
  const {
    play,
    currentTrack,
    isPlaying,
    pause
  } = usePlayerStore();

  // Format seconds to mm:ss
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };
  const handleShare = (track: any) => {
    const text = `Listening to ${track.title} by ${track.artist} on Nusantara Stream!`;
    const url = window.location.href;
    try {
      navigator.clipboard.writeText(`${text} ${url}`);
      alert('Link copied to clipboard');
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };
  return <section className="py-16" data-unique-id="1108c126-dd74-43c3-9e3e-9eb6d7d424b7" data-file-name="components/music/music-player.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="2d932810-178e-4740-b93d-68d404a3310d" data-file-name="components/music/music-player.tsx">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8" data-unique-id="e5b82035-8411-4067-9dc0-886a370ff63d" data-file-name="components/music/music-player.tsx">
          <div className="lg:col-span-2" data-unique-id="3b5d5853-e5be-477b-816d-3cdd4cb42a11" data-file-name="components/music/music-player.tsx">
            <div className="mb-6" data-unique-id="d5d53cfd-f38c-4541-b054-c2389d5a2fd5" data-file-name="components/music/music-player.tsx">
              <h2 className="text-2xl font-semibold mb-4" data-unique-id="b457a9d4-03d4-4c8d-bd41-b312f113afa2" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="1ce36916-b97d-4a82-a2d4-43407bcfb06e" data-file-name="components/music/music-player.tsx">Musik Lokal Anda</span></h2>
              <p className="text-muted-foreground" data-unique-id="f3928e2f-43d7-48df-98a2-6aff8b566ce7" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="e7ded0e3-bc00-4dfa-8633-ef8a655d4cad" data-file-name="components/music/music-player.tsx">
                File musik yang telah diunggah dari penyimpanan internal Anda
              </span></p>
            </div>
            
            <div className="space-y-2" data-unique-id="4097396d-32a3-4183-99e6-9db7b14ede2f" data-file-name="components/music/music-player.tsx" data-dynamic-text="true">
              <div className="grid grid-cols-12 py-2 px-4 text-sm text-muted-foreground border-b border-border" data-unique-id="caf59c6f-b70d-4764-9986-27709418d8a4" data-file-name="components/music/music-player.tsx">
                <div className="col-span-1" data-unique-id="30356bd3-9417-4bf2-934c-f034bb2c3cc8" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="8bcc506a-0b5b-4387-9ae3-1533e2b9675d" data-file-name="components/music/music-player.tsx">#</span></div>
                <div className="col-span-5" data-unique-id="39ca2ce3-207f-41d8-9d9c-9681e6183b5e" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="7b9c2670-5925-4c78-a822-67568977161b" data-file-name="components/music/music-player.tsx">Judul</span></div>
                <div className="col-span-3" data-unique-id="f4d694e1-7a44-4574-bf24-e959b0bee138" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="8f89a101-ae50-4ab3-96ba-2c06e8e1d0f9" data-file-name="components/music/music-player.tsx">Artist</span></div>
                <div className="col-span-2" data-unique-id="87a04f74-5d59-440c-84e1-6fe9975874b9" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="6e6078c8-162c-4820-ba3b-c9f24a703398" data-file-name="components/music/music-player.tsx">Duration</span></div>
                <div className="col-span-1" data-unique-id="b951f9ef-8f50-4fdc-83ff-131771def316" data-file-name="components/music/music-player.tsx"></div>
              </div>
              
              {sampleTracks.map((track, index) => <motion.div key={track.id} initial={{
              opacity: 0,
              y: 10
            }} animate={{
              opacity: 1,
              y: 0
            }} transition={{
              delay: index * 0.1
            }} className={`grid grid-cols-12 items-center py-3 px-4 rounded-md ${currentTrack?.id === track.id ? 'bg-accent' : 'hover:bg-accent/50'} transition-colors cursor-pointer`} onClick={() => play(track)} data-unique-id="e56561a2-9887-42fe-a631-0857ecb4a5ae" data-file-name="components/music/music-player.tsx">
                  <div className="col-span-1 text-muted-foreground" data-unique-id="57786d38-2db8-4028-bb35-846886fb18d7" data-file-name="components/music/music-player.tsx" data-dynamic-text="true">
                    {currentTrack?.id === track.id && isPlaying ? <div className="flex items-center justify-center w-6 h-6" data-unique-id="137b9cc2-11b1-4258-8642-e30c5fa3f315" data-file-name="components/music/music-player.tsx">
                        <div className="flex gap-0.5" data-unique-id="0d9dd987-7575-4bef-bee8-35cd1031d8c5" data-file-name="components/music/music-player.tsx">
                          <span className="w-1 h-6 bg-primary animate-music-bars" data-unique-id="e167ae11-cddc-4d55-a62e-01fc03d1bdc5" data-file-name="components/music/music-player.tsx"></span>
                          <span className="w-1 h-6 bg-primary animate-music-bars animation-delay-200" data-unique-id="31996f3a-25ff-4e58-ac07-a19b6cf002c9" data-file-name="components/music/music-player.tsx"></span>
                          <span className="w-1 h-6 bg-primary animate-music-bars animation-delay-400" data-unique-id="9e4e3df8-777c-4cee-b901-7a344a9707bc" data-file-name="components/music/music-player.tsx"></span>
                        </div>
                      </div> : <span data-unique-id="bd5ea52a-7b87-414d-ad69-adc7b57117ff" data-file-name="components/music/music-player.tsx" data-dynamic-text="true">{index + 1}</span>}
                  </div>
                  
                  <div className="col-span-5 font-medium truncate" data-unique-id="71016b41-e77c-41dd-b96f-6c0de27dc964" data-file-name="components/music/music-player.tsx" data-dynamic-text="true">
                    {track.title}
                  </div>
                  
                  <div className="col-span-3 text-muted-foreground truncate" data-unique-id="0c53c8d1-863a-40c6-9885-b52bb6f589b0" data-file-name="components/music/music-player.tsx" data-dynamic-text="true">
                    {track.artist}
                  </div>
                  
                  <div className="col-span-2 text-muted-foreground" data-unique-id="83dfaf0a-6272-49c7-94ab-789b9794006b" data-file-name="components/music/music-player.tsx" data-dynamic-text="true">
                    {formatTime(track.duration)}
                  </div>
                  
                  <div className="col-span-1 flex justify-end" data-unique-id="f97952b1-3bab-455a-9fab-4f4e61b07e14" data-file-name="components/music/music-player.tsx">
                    <button onClick={e => {
                  e.stopPropagation();
                  handleShare(track);
                }} className="text-muted-foreground hover:text-foreground" data-unique-id="e4348d85-c8e9-43ae-a8e9-5dd4bde68379" data-file-name="components/music/music-player.tsx">
                      <Share2 className="h-4 w-4" data-unique-id="31b7794f-8143-4d5c-b0e9-b156444bfddd" data-file-name="components/music/music-player.tsx" data-dynamic-text="true" />
                    </button>
                  </div>
                </motion.div>)}
            </div>
          </div>
          
          <div data-unique-id="5ed08425-370b-4a56-b813-b67173b689ce" data-file-name="components/music/music-player.tsx">
            <div className="bg-card border border-border rounded-xl p-6" data-unique-id="99d9a0df-ba38-4294-8238-b8f97319cd11" data-file-name="components/music/music-player.tsx">
              <h3 className="text-xl font-semibold mb-4" data-unique-id="83df9dd1-85d9-467e-96c6-71aa366c4161" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="f164a5aa-e8a2-48a6-9d9e-2ce604134a62" data-file-name="components/music/music-player.tsx">Format yang Didukung</span></h3>
              
              <div className="space-y-4" data-unique-id="b2398f39-f75b-4a88-8b63-a8a24b1b6509" data-file-name="components/music/music-player.tsx">
                <div className="flex items-start gap-3" data-unique-id="2dc6e2ec-1518-4d49-98fb-88ab7ac0dad9" data-file-name="components/music/music-player.tsx">
                  <div className="h-8 w-8 rounded-full bg-chart-1/20 flex items-center justify-center" data-unique-id="8d559016-545c-458e-9635-3cf9b8614c09" data-file-name="components/music/music-player.tsx">
                    <span className="font-medium text-chart-1" data-unique-id="8f69986c-ff3c-4d38-bfe3-21c13aa47de5" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="dc4ab6ad-3219-4e56-a3db-c643ce60e429" data-file-name="components/music/music-player.tsx">MP3</span></span>
                  </div>
                  <div data-unique-id="613e92e7-5c3d-4dd5-8937-17657a5cc5f7" data-file-name="components/music/music-player.tsx">
                    <p className="font-medium" data-unique-id="145c9690-f14a-4e08-a0e2-625f2a5f7ca6" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="71553724-7205-4f5f-8435-c9128d92ba36" data-file-name="components/music/music-player.tsx">MP3 Audio</span></p>
                    <p className="text-sm text-muted-foreground" data-unique-id="4eafd900-6424-4ec7-9589-ba5fb85925d2" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="75668e75-7a1c-4682-a408-4c81eb7917a6" data-file-name="components/music/music-player.tsx">Format audio paling populer dan kompatibel</span></p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3" data-unique-id="ade1e67f-ddad-46a7-a977-4a9c7c9f071e" data-file-name="components/music/music-player.tsx">
                  <div className="h-8 w-8 rounded-full bg-chart-2/20 flex items-center justify-center" data-unique-id="bb2fb76c-e83a-45bd-bc29-a7c347a550c7" data-file-name="components/music/music-player.tsx">
                    <span className="font-medium text-chart-2" data-unique-id="c841fe29-067c-4404-bcd4-bc69bccfa693" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="9e759d72-d5dd-4475-b149-71151d3593f0" data-file-name="components/music/music-player.tsx">FLAC</span></span>
                  </div>
                  <div data-unique-id="57c516aa-21e7-48d6-9850-89faf46d14d4" data-file-name="components/music/music-player.tsx">
                    <p className="font-medium" data-unique-id="f1bd62b9-08a2-4a3a-b525-5d38c0821c19" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="d21f330c-931d-4734-b834-af42cb0adbcb" data-file-name="components/music/music-player.tsx">FLAC Audio</span></p>
                    <p className="text-sm text-muted-foreground" data-unique-id="695cd28b-9421-409a-9343-2c7857cd146d" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="07d58d76-6677-4729-b3fa-4e39d87be0f2" data-file-name="components/music/music-player.tsx">Audio lossless dengan kualitas tinggi</span></p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3" data-unique-id="0603e1e7-f82c-4a55-9614-517766baac67" data-file-name="components/music/music-player.tsx">
                  <div className="h-8 w-8 rounded-full bg-chart-3/20 flex items-center justify-center" data-unique-id="18bdbfc7-d9b9-4a14-a8b8-185116222736" data-file-name="components/music/music-player.tsx">
                    <span className="font-medium text-chart-3" data-unique-id="8f7a3cfe-9595-43ab-98ed-2411b10d9eec" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="9d538ecb-545d-446f-a168-281f0610716f" data-file-name="components/music/music-player.tsx">WAV</span></span>
                  </div>
                  <div data-unique-id="404e3c59-1505-418a-8138-f827e0249c5b" data-file-name="components/music/music-player.tsx">
                    <p className="font-medium" data-unique-id="17ab7d7d-c5f3-4ce9-83a6-d7ebe9cbc80c" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="95308f84-e4b3-4eb8-8040-2ec7dadef764" data-file-name="components/music/music-player.tsx">WAV Audio</span></p>
                    <p className="text-sm text-muted-foreground" data-unique-id="78f27ce3-d8da-493f-bbe4-737171a9a00b" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="285c5604-034b-4d18-bb54-cfbecec29cce" data-file-name="components/music/music-player.tsx">Format audio tidak terkompresi</span></p>
                  </div>
                </div>
                
                <div className="flex items-start gap-3" data-unique-id="371004d6-49dc-4035-9b14-d46c438cc32b" data-file-name="components/music/music-player.tsx">
                  <div className="h-8 w-8 rounded-full bg-chart-4/20 flex items-center justify-center" data-unique-id="211dab18-cd8d-4510-8839-20a612aac735" data-file-name="components/music/music-player.tsx">
                    <span className="font-medium text-chart-4" data-unique-id="73c4b4bf-299f-4706-8a61-8f9fc7e64339" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="483ff22e-809c-4352-a00b-e5e1c03873df" data-file-name="components/music/music-player.tsx">32</span></span>
                  </div>
                  <div data-unique-id="a0b63ba3-05f0-4b66-b1e8-17dd97dc11e4" data-file-name="components/music/music-player.tsx">
                    <p className="font-medium" data-unique-id="612fb16f-f35f-437e-99e1-a61fe7591fdf" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="72009ead-1b4d-4d76-90d3-dada60832217" data-file-name="components/music/music-player.tsx">32-bit Audio</span></p>
                    <p className="text-sm text-muted-foreground" data-unique-id="c9c100b1-8fd8-4b7e-acab-a572e72ed3a7" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="c9e756d0-8408-4cbd-9bae-10628fb5465b" data-file-name="components/music/music-player.tsx">Audio dengan dynamic range yang lebih luas</span></p>
                  </div>
                </div>
              </div>
              
              <div className="mt-6 pt-6 border-t border-border" data-unique-id="b8fd1b2e-3551-49d4-9c14-c068c907fd85" data-file-name="components/music/music-player.tsx">
                <p className="text-sm text-muted-foreground" data-unique-id="cba18b7e-c903-48d0-8a93-233521b4c961" data-file-name="components/music/music-player.tsx"><span className="editable-text" data-unique-id="9312eabe-a2ff-4934-b285-ce0e2a691da6" data-file-name="components/music/music-player.tsx">
                  Nusantara Stream mendukung berbagai format audio untuk memberikan pengalaman mendengarkan yang optimal bagi pengguna.
                </span></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>;
}