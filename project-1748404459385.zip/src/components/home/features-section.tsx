'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Radio, Tv, Headphones, Music, Share2, List } from 'lucide-react';
export default function FeaturesSection() {
  const features = [{
    icon: <Radio className="h-6 w-6" />,
    title: 'Radio Indonesia',
    description: 'Streaming radio dari berbagai kota di Indonesia dengan kualitas audio tinggi.',
    color: 'bg-chart-1/10',
    iconColor: 'text-chart-1'
  }, {
    icon: <Tv className="h-6 w-6" />,
    title: 'TV Live',
    description: 'Saksikan siaran TV lokal Indonesia secara langsung tanpa buffering.',
    color: 'bg-chart-2/10',
    iconColor: 'text-chart-2'
  }, {
    icon: <Headphones className="h-6 w-6" />,
    title: 'Podcast Player',
    description: 'Dengarkan podcast terpopuler dari kreator konten Indonesia.',
    color: 'bg-chart-3/10',
    iconColor: 'text-chart-3'
  }, {
    icon: <Music className="h-6 w-6" />,
    title: 'Musik Lokal',
    description: 'Putar file musik FLAC, MP3, WAV dan 32-bit audio dari penyimpanan internal.',
    color: 'bg-chart-4/10',
    iconColor: 'text-chart-4'
  }, {
    icon: <Share2 className="h-6 w-6" />,
    title: 'Bagikan Konten',
    description: 'Bagikan musik atau siaran favorit ke WhatsApp, Facebook, dan Instagram.',
    color: 'bg-chart-5/10',
    iconColor: 'text-chart-5'
  }, {
    icon: <List className="h-6 w-6" />,
    title: 'Playlist Musik',
    description: 'Buat dan kelola playlist kustom untuk semua konten favorit Anda.',
    color: 'bg-chart-1/10',
    iconColor: 'text-chart-1'
  }];
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };
  return <section className="py-20 bg-muted/50" data-unique-id="1ecc524a-7fb5-4a2f-b15b-785b0b7ddec2" data-file-name="components/home/features-section.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="4b18299a-fb51-4446-aabb-816bd0e0ea1e" data-file-name="components/home/features-section.tsx">
        <div className="text-center mb-12" data-unique-id="4e9c49c6-a5ac-48ae-81fc-e2773b54aad5" data-file-name="components/home/features-section.tsx">
          <motion.h2 initial={{
          opacity: 0,
          y: -20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} className="text-3xl font-bold mb-4" data-unique-id="cd0a79d3-3a28-4e53-bb2c-075f71319702" data-file-name="components/home/features-section.tsx"><span className="editable-text" data-unique-id="096ace01-cd6c-4393-bfe3-2efe21c1dee5" data-file-name="components/home/features-section.tsx">
            Fitur Lengkap untuk Kebutuhan Streaming Anda
          </span></motion.h2>
          <motion.p initial={{
          opacity: 0
        }} whileInView={{
          opacity: 1
        }} viewport={{
          once: true
        }} transition={{
          delay: 0.2
        }} className="text-muted-foreground max-w-2xl mx-auto" data-unique-id="26d5e9d4-75cd-439e-b589-08ba204f1a0f" data-file-name="components/home/features-section.tsx"><span className="editable-text" data-unique-id="dec27679-5353-4fac-9323-5af41c7b71a2" data-file-name="components/home/features-section.tsx">
            Nusantara Stream menyediakan beragam fitur untuk mengakses konten multimedia Indonesia dalam satu platform terpadu.
          </span></motion.p>
        </div>
        
        <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" variants={containerVariants} initial="hidden" whileInView="visible" viewport={{
        once: true,
        amount: 0.1
      }} data-unique-id="00d07d8c-46d1-42ff-ab18-57ddfd1aa7c4" data-file-name="components/home/features-section.tsx" data-dynamic-text="true">
          {features.map((feature, index) => <motion.div key={index} variants={itemVariants} className="bg-card border border-border rounded-xl p-6 hover:shadow-md transition-shadow" data-unique-id="f4a3c4d7-4c3a-48f6-adc9-c89d4ea646e9" data-file-name="components/home/features-section.tsx">
              <div className={`${feature.color} p-3 rounded-lg inline-flex mb-4`} data-unique-id="74341158-0809-4ca6-bcab-ee80ec55c0df" data-file-name="components/home/features-section.tsx">
                <div className={feature.iconColor} data-unique-id="f1888461-f132-47a0-a974-c3f0fe46b4a6" data-file-name="components/home/features-section.tsx" data-dynamic-text="true">{feature.icon}</div>
              </div>
              <h3 className="text-xl font-medium mb-3" data-unique-id="401238d8-1866-42b4-99e6-055a3584c2aa" data-file-name="components/home/features-section.tsx" data-dynamic-text="true">{feature.title}</h3>
              <p className="text-muted-foreground" data-unique-id="c0eeb083-7ad2-4e7d-a1c2-da3903101de4" data-file-name="components/home/features-section.tsx" data-dynamic-text="true">{feature.description}</p>
            </motion.div>)}
        </motion.div>
      </div>
    </section>;
}