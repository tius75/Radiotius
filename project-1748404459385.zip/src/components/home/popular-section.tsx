'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Play, Radio, Tv } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function PopularSection() {
  const {
    play
  } = usePlayerStore();
  const popularRadio = [{
    id: 'prambors',
    title: 'Prambors FM',
    genre: 'Pop & Entertainment',
    thumbnail: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=300&auto=format&fit=crop',
    url: 'https://23683.live.streamtheworld.com/PRAMBORS_FM.mp3',
    type: 'radio' as const
  }, {
    id: 'hardrock',
    title: 'Hard Rock FM',
    genre: 'Rock & Alternative',
    thumbnail: 'https://images.unsplash.com/photo-1471478331149-c72f17e33c73?q=80&w=300&auto=format&fit=crop',
    url: 'https://n11.radiojar.com/7csmg90fuqruv?rj-ttl=5&rj-tok=AAABhd0MyqEAxV3qy78UI1Klww',
    type: 'radio' as const
  }, {
    id: 'genFM',
    title: 'Gen FM',
    genre: 'Pop & News',
    thumbnail: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=300&auto=format&fit=crop',
    url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
    type: 'radio' as const
  }, {
    id: 'hotfm',
    title: 'HOT FM',
    genre: 'Contemporary',
    thumbnail: "https://picsum.photos/200",
    url: 'https://n02.radiojar.com/yg8ne2v80k8uv?rj-ttl=5&rj-tok=AAABhd0MFXIAjDQBWinMWXJXvQ',
    type: 'radio' as const
  }];
  const popularTV = [{
    id: 'metrotv',
    title: 'Metro TV',
    genre: 'News',
    thumbnail: "https://picsum.photos/200",
    url: 'https://cdn-telkomsel-01.akamaized.net/Content/HLS/Live/channel(bd164a95-722d-40db-a596-687c8123f197)/index.m3u8',
    type: 'tv' as const
  }, {
    id: 'tvone',
    title: 'TV One',
    genre: 'News & Entertainment',
    thumbnail: "https://picsum.photos/200",
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'tv' as const
  }];
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.1
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };
  return <section className="py-20" data-unique-id="6f419348-656b-4ea8-9306-577cd1c9a7a5" data-file-name="components/home/popular-section.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="45cf9362-7cc8-4342-b027-8cffa4f39b5f" data-file-name="components/home/popular-section.tsx">
        <motion.div initial={{
        opacity: 0
      }} whileInView={{
        opacity: 1
      }} viewport={{
        once: true
      }} className="flex flex-col md:flex-row md:items-end justify-between mb-12" data-unique-id="8d150d6f-4bc2-43cc-94a9-f662f877365f" data-file-name="components/home/popular-section.tsx">
          <div data-unique-id="e2de9e3b-b214-46cd-8a96-676e20e2ab19" data-file-name="components/home/popular-section.tsx">
            <h2 className="text-3xl font-bold mb-4" data-unique-id="f22cfe5e-b3d4-4d34-aa54-3a0e88b1493d" data-file-name="components/home/popular-section.tsx"><span className="editable-text" data-unique-id="60754a91-1ea9-463c-bfc3-1f92beeb17dd" data-file-name="components/home/popular-section.tsx">Populer di Nusantara</span></h2>
            <p className="text-muted-foreground max-w-2xl" data-unique-id="48f3183a-b1fb-4783-b03e-91a609ec86cc" data-file-name="components/home/popular-section.tsx"><span className="editable-text" data-unique-id="d0e78884-002e-4af9-9a7c-e462bce57133" data-file-name="components/home/popular-section.tsx">
              Jelajahi radio, TV, dan podcast terpopuler dari seluruh Indonesia.
            </span></p>
          </div>
        </motion.div>
        
        <div className="mb-16" data-unique-id="218b1015-72ce-4998-87fa-bbda84d2491b" data-file-name="components/home/popular-section.tsx">
          <div className="flex items-center gap-3 mb-6" data-unique-id="110a3c02-bd70-4ae9-8fcd-542607ed20b5" data-file-name="components/home/popular-section.tsx">
            <Radio className="h-5 w-5 text-chart-1" />
            <h3 className="text-xl font-medium" data-unique-id="c362a89f-e1f9-47a7-8ed4-7fbaaba252f8" data-file-name="components/home/popular-section.tsx"><span className="editable-text" data-unique-id="23b5a499-b2e6-4575-9c33-8a07dda568dc" data-file-name="components/home/popular-section.tsx">Radio Populer</span></h3>
          </div>
          
          <motion.div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6" variants={containerVariants} initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.1
        }} data-unique-id="27c67a12-b041-4b6d-83e4-e21db922cc32" data-file-name="components/home/popular-section.tsx" data-dynamic-text="true">
            {popularRadio.map(station => <motion.div key={station.id} variants={itemVariants} className="group bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow" data-unique-id="b756ca34-1a61-407b-9a10-f8090725bf49" data-file-name="components/home/popular-section.tsx">
                <div className="relative h-48" data-unique-id="a483b196-29c2-4459-992c-3f6601cc292e" data-file-name="components/home/popular-section.tsx">
                  <img src={station.thumbnail} alt={station.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" data-unique-id="239e3b65-d4a1-4078-9837-fc20e5117d10" data-file-name="components/home/popular-section.tsx" />
                  
                  <button onClick={() => play(station)} className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity" data-unique-id="03c04ea9-13ab-42ab-980b-7b1b8407ba45" data-file-name="components/home/popular-section.tsx">
                    <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center" data-unique-id="07ee04d0-a0d2-4d9a-9afd-c9c3dc9fc4e9" data-file-name="components/home/popular-section.tsx">
                      <Play className="h-5 w-5 text-primary-foreground" />
                    </div>
                  </button>
                </div>
                
                <div className="p-4" data-unique-id="98e14522-9b2e-414b-bea0-253066f65449" data-file-name="components/home/popular-section.tsx">
                  <h4 className="font-medium mb-1" data-unique-id="ff1872fd-1d0f-49db-a17e-197e6fc0ec61" data-file-name="components/home/popular-section.tsx" data-dynamic-text="true">{station.title}</h4>
                  <p className="text-sm text-muted-foreground" data-unique-id="d4403aaf-1cbe-4c7d-8691-1c4e378c9228" data-file-name="components/home/popular-section.tsx" data-dynamic-text="true">{station.genre}</p>
                </div>
              </motion.div>)}
          </motion.div>
        </div>
        
        <div data-unique-id="4b3bc15a-fdc1-4038-a181-04e00662028f" data-file-name="components/home/popular-section.tsx">
          <div className="flex items-center gap-3 mb-6" data-unique-id="c1dbf326-e771-412d-aefc-4605080c0f38" data-file-name="components/home/popular-section.tsx">
            <Tv className="h-5 w-5 text-chart-2" />
            <h3 className="text-xl font-medium" data-unique-id="52987635-461e-42d0-afca-0f79981ece15" data-file-name="components/home/popular-section.tsx"><span className="editable-text" data-unique-id="5672ad1b-ead9-447c-8104-07b2d4cf29db" data-file-name="components/home/popular-section.tsx">TV Populer</span></h3>
          </div>
          
          <motion.div className="grid grid-cols-1 sm:grid-cols-2 gap-6" variants={containerVariants} initial="hidden" whileInView="visible" viewport={{
          once: true,
          amount: 0.1
        }} data-unique-id="4c1641e8-fa52-42ff-861f-7c0c719da46b" data-file-name="components/home/popular-section.tsx" data-dynamic-text="true">
            {popularTV.map(channel => <motion.div key={channel.id} variants={itemVariants} className="group bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow" data-unique-id="aced5843-8283-44f0-b4dc-53887f34a93e" data-file-name="components/home/popular-section.tsx">
                <div className="relative h-48 lg:h-64" data-unique-id="ef79c79a-9fde-411c-a689-3a3d4dce1691" data-file-name="components/home/popular-section.tsx">
                  <img src={channel.thumbnail} alt={channel.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" data-unique-id="96fc2c08-bb29-4207-9b5c-23f8cffa41ca" data-file-name="components/home/popular-section.tsx" />
                  
                  <button onClick={() => play(channel)} className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity" data-unique-id="98f10045-907b-4d03-825e-c50305e84bb0" data-file-name="components/home/popular-section.tsx">
                    <div className="h-12 w-12 rounded-full bg-primary flex items-center justify-center" data-unique-id="74481bb4-8eed-4c2d-b3c5-8421a27b4475" data-file-name="components/home/popular-section.tsx">
                      <Play className="h-5 w-5 text-primary-foreground" />
                    </div>
                  </button>
                </div>
                
                <div className="p-4" data-unique-id="22f5b568-b355-4bad-94f2-556f6c703d84" data-file-name="components/home/popular-section.tsx">
                  <h4 className="font-medium mb-1" data-unique-id="ccc75bd1-a172-485b-9186-f5b2c6a92ff9" data-file-name="components/home/popular-section.tsx" data-dynamic-text="true">{channel.title}</h4>
                  <p className="text-sm text-muted-foreground" data-unique-id="dda30cc1-78ea-48e8-a0f4-4a29f9595231" data-file-name="components/home/popular-section.tsx" data-dynamic-text="true">{channel.genre}</p>
                </div>
              </motion.div>)}
          </motion.div>
        </div>
      </div>
    </section>;
}