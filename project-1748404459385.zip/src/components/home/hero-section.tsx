'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Radio, Tv, Headphones, Music } from 'lucide-react';
export default function HeroSection() {
  return <section className="relative py-20 overflow-hidden" data-unique-id="f5d88896-66c0-4afe-a488-3d012c74d7a2" data-file-name="components/home/hero-section.tsx" data-dynamic-text="true">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10 overflow-hidden" data-unique-id="bfaaef71-d3f7-4699-84bb-6bbb7b4fbefc" data-file-name="components/home/hero-section.tsx">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] rounded-full bg-chart-1/10 blur-3xl" data-unique-id="bfaf0502-d668-44ed-bbe5-7192b30f8b70" data-file-name="components/home/hero-section.tsx" />
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] rounded-full bg-chart-2/10 blur-3xl" data-unique-id="1f460fe8-c56e-4725-8627-1c163c0cc90a" data-file-name="components/home/hero-section.tsx" />
      </div>
      
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="0c5a481f-f1fb-4bd5-97d1-507480824cfc" data-file-name="components/home/hero-section.tsx">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center" data-unique-id="3e007143-ca56-4c1c-b86b-2bc6e978022e" data-file-name="components/home/hero-section.tsx">
          <motion.div initial={{
          opacity: 0,
          x: -20
        }} animate={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }} data-unique-id="c1226867-ee37-4ad5-ad55-08e2857bd037" data-file-name="components/home/hero-section.tsx">
            <h1 className="text-4xl md:text-5xl font-bold mb-6" data-unique-id="2df5e3f6-1f9b-4c49-a444-18e1440224a1" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="79418495-5b02-4e6d-ac31-bccbf19f5c0c" data-file-name="components/home/hero-section.tsx">
              Eksplorasi Konten 
              </span><span className="bg-gradient-to-r from-chart-1 to-chart-2 bg-clip-text text-transparent" data-unique-id="4fff3318-fca5-4af8-b5e6-aacad35b851e" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="017b5234-a9c7-4470-856d-1d0b3b71c526" data-file-name="components/home/hero-section.tsx"> Nusantara</span></span><span className="editable-text" data-unique-id="e91a3042-d0dc-4eac-96fd-f61c579f258c" data-file-name="components/home/hero-section.tsx"> 
              Dalam Satu Platform
            </span></h1>
            <p className="text-xl text-muted-foreground mb-8" data-unique-id="18cd865f-b5ed-48ec-924c-4c6b4887665e" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="b23a482b-4387-43fb-b179-04e6b26d99d7" data-file-name="components/home/hero-section.tsx">
              Radio Indonesia, siaran TV lokal, podcast eksklusif, dan pemutar musik
              lengkap dalam satu aplikasi streaming.
            </span></p>
            <div className="flex flex-wrap gap-4" data-unique-id="25960c7c-095c-4cd5-a163-77cee904df98" data-file-name="components/home/hero-section.tsx">
              <Link href="/radio" className="px-6 py-3 bg-primary text-primary-foreground rounded-md hover:opacity-90 transition-opacity" data-unique-id="d96a09d0-5038-451e-8b44-7df7cf677c0b" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="d1930b04-7187-4fc7-9517-2c55f0b8acb7" data-file-name="components/home/hero-section.tsx">
                Mulai Streaming
              </span></Link>
              <Link href="/music" className="px-6 py-3 bg-accent text-accent-foreground rounded-md border border-border hover:bg-accent/80 transition-colors" data-unique-id="95100a8f-cfcc-4d8b-b03b-6a9a3899f6b1" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="3975befa-50b6-46ce-b0f0-d43b0c7afb21" data-file-name="components/home/hero-section.tsx">
                Jelajahi Musik
              </span></Link>
            </div>
          </motion.div>
          
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.8,
          delay: 0.2
        }} className="relative h-[450px] rounded-lg overflow-hidden shadow-xl" data-unique-id="7cf7791a-bf8b-4f7c-97ea-4fecb7851334" data-file-name="components/home/hero-section.tsx" data-dynamic-text="true">
            <div className="absolute inset-0 bg-gradient-to-tr from-chart-1/20 to-chart-2/20 z-10" data-unique-id="f4ed203c-f262-4957-adbf-7efe5e611198" data-file-name="components/home/hero-section.tsx"></div>
            <img src="https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=1200&auto=format&fit=crop" alt="Indonesian music streaming" className="object-cover w-full h-full brightness-90" data-unique-id="bc80b061-427c-4723-9424-6e3c7e06475a" data-file-name="components/home/hero-section.tsx" />
            
            {/* Floating feature cards */}
            <div className="absolute bottom-8 left-8 right-8 z-20 flex gap-4" data-unique-id="0ee3169b-0ff6-4447-82a7-71f243967291" data-file-name="components/home/hero-section.tsx">
              <motion.div initial={{
              y: 20,
              opacity: 0
            }} animate={{
              y: 0,
              opacity: 1
            }} transition={{
              delay: 0.6
            }} className="bg-card/90 backdrop-blur-sm p-3 rounded-lg flex items-center gap-3 flex-grow" data-unique-id="226851ba-6479-47f0-9c06-cf5857007abf" data-file-name="components/home/hero-section.tsx">
                <div className="bg-chart-1/20 p-2 rounded-md" data-unique-id="94ba991f-b635-427c-942f-99556afa1da5" data-file-name="components/home/hero-section.tsx">
                  <Radio className="h-5 w-5 text-chart-1" />
                </div>
                <div className="text-sm" data-unique-id="e6842eb7-330a-49a2-8943-fd08a0c5b8d6" data-file-name="components/home/hero-section.tsx">
                  <p className="font-medium" data-unique-id="01782556-3f1d-46fc-bc6f-43787f559cb2" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="e4fe6138-a0f1-427e-b8d3-fdb025fc7d2e" data-file-name="components/home/hero-section.tsx">Radio Indonesia</span></p>
                  <p className="text-xs text-muted-foreground" data-unique-id="18eff458-9f8a-4993-a23b-0f8d2b609ec6" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="f9cb0053-dec4-4107-80a1-95b181df7d60" data-file-name="components/home/hero-section.tsx">100+ stasiun radio</span></p>
                </div>
              </motion.div>
              
              <motion.div initial={{
              y: 20,
              opacity: 0
            }} animate={{
              y: 0,
              opacity: 1
            }} transition={{
              delay: 0.8
            }} className="bg-card/90 backdrop-blur-sm p-3 rounded-lg flex items-center gap-3 flex-grow" data-unique-id="66b93a5f-89e2-43d3-a82a-f05b083e3dce" data-file-name="components/home/hero-section.tsx">
                <div className="bg-chart-2/20 p-2 rounded-md" data-unique-id="6f7fed31-732d-423b-b8c2-f746878f861c" data-file-name="components/home/hero-section.tsx">
                  <Tv className="h-5 w-5 text-chart-2" />
                </div>
                <div className="text-sm" data-unique-id="af1f31e9-e4a3-44cc-92bb-56b7a5427182" data-file-name="components/home/hero-section.tsx">
                  <p className="font-medium" data-unique-id="5310364e-c728-4989-8485-49870780fa14" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="3a1a09b5-a2e9-4b28-b5b0-c0f57aed8be6" data-file-name="components/home/hero-section.tsx">Siaran TV Lokal</span></p>
                  <p className="text-xs text-muted-foreground" data-unique-id="a5da11d4-fe7e-4e1c-a89c-65e5b5f1d0cd" data-file-name="components/home/hero-section.tsx"><span className="editable-text" data-unique-id="92a4570d-d247-4aa1-b9e4-c070848f47b7" data-file-name="components/home/hero-section.tsx">Streaming langsung</span></p>
                </div>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>;
}