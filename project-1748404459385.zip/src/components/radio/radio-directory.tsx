'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Play, Info, Share2 } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function RadioDirectory() {
  const {
    play
  } = usePlayerStore();
  const [showInfo, setShowInfo] = React.useState<string | null>(null);
  const regions = [{
    id: 'jakarta',
    name: 'Jakarta'
  }, {
    id: 'bandung',
    name: 'Bandung'
  }, {
    id: 'surabaya',
    name: 'Surabaya'
  }, {
    id: 'yogyakarta',
    name: 'Yogyakarta'
  }, {
    id: 'bali',
    name: 'Bali'
  }, {
    id: 'other',
    name: 'Lainnya'
  }];
  const [activeRegion, setActiveRegion] = React.useState('jakarta');
  const radioStations = {
    jakarta: [{
      id: 'prambors-jakarta',
      title: 'Prambors FM Jakarta',
      frequency: '102.2 FM',
      genre: 'Pop & Entertainment',
      thumbnail: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=300&auto=format&fit=crop',
      url: 'https://23683.live.streamtheworld.com/PRAMBORS_FM.mp3',
      description: 'Radio anak muda nomor 1 di Jakarta dengan konten entertainment dan musik populer.',
      type: 'radio' as const
    }, {
      id: 'gen-jakarta',
      title: 'Gen FM Jakarta',
      frequency: '98.7 FM',
      genre: 'Pop & News',
      thumbnail: 'https://images.unsplash.com/photo-1614680376573-df3480f0c6ff?q=80&w=300&auto=format&fit=crop',
      url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
      description: 'Stasiun radio dengan konten pop dan hiburan untuk semua kalangan di Jakarta.',
      type: 'radio' as const
    }, {
      id: 'hardrock-jakarta',
      title: 'Hard Rock FM Jakarta',
      frequency: '87.8 FM',
      genre: 'Rock & Alternative',
      thumbnail: 'https://images.unsplash.com/photo-1471478331149-c72f17e33c73?q=80&w=300&auto=format&fit=crop',
      url: 'https://n11.radiojar.com/7csmg90fuqruv?rj-ttl=5&rj-tok=AAABhd0MyqEAxV3qy78UI1Klww',
      description: 'Stasiun radio dengan fokus musik rock dan alternative terbaik Indonesia dan mancanegara.',
      type: 'radio' as const
    }, {
      id: 'iradio-jakarta',
      title: 'I-Radio Jakarta',
      frequency: '89.6 FM',
      genre: 'Indonesian Pop',
      thumbnail: 'https://images.unsplash.com/photo-1513829596324-4bb2800c5efb?q=80&w=300&auto=format&fit=crop',
      url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
      description: 'Radio yang memutarkan 100% musik Indonesia terbaik.',
      type: 'radio' as const
    }],
    bandung: [{
      id: 'prambors-bandung',
      title: 'Prambors FM Bandung',
      frequency: '98.4 FM',
      genre: 'Pop & Entertainment',
      thumbnail: 'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?q=80&w=300&auto=format&fit=crop',
      url: 'https://23683.live.streamtheworld.com/PRAMBORS_FM.mp3',
      description: 'Radio anak muda nomor 1 di Bandung dengan konten entertainment dan musik populer.',
      type: 'radio' as const
    }, {
      id: 'ardan-bandung',
      title: 'Ardan Radio Bandung',
      frequency: '105.9 FM',
      genre: 'Pop & Entertainment',
      thumbnail: 'https://images.unsplash.com/photo-1487180144351-b8472da7d491?q=80&w=300&auto=format&fit=crop',
      url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
      description: 'Radio pop terkemuka di Bandung dengan berbagai program hiburan.',
      type: 'radio' as const
    }],
    surabaya: [{
      id: 'suara-surabaya',
      title: 'Suara Surabaya',
      frequency: '100.0 FM',
      genre: 'News & Information',
      thumbnail: 'https://images.unsplash.com/photo-1519121785383-3229633bb75b?q=80&w=300&auto=format&fit=crop',
      url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
      description: 'Radio informasi dan berita terdepan di Surabaya.',
      type: 'radio' as const
    }],
    yogyakarta: [{
      id: 'geronimo-yogya',
      title: 'Geronimo FM',
      frequency: '106.1 FM',
      genre: 'Pop & Entertainment',
      thumbnail: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=300&auto=format&fit=crop',
      url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
      description: 'Radio populer di Yogyakarta untuk anak muda.',
      type: 'radio' as const
    }],
    bali: [{
      id: 'hardrock-bali',
      title: 'Hard Rock FM Bali',
      frequency: '87.8 FM',
      genre: 'Rock & Alternative',
      thumbnail: 'https://images.unsplash.com/photo-1555538995-7181cc10e079?q=80&w=300&auto=format&fit=crop',
      url: 'https://n11.radiojar.com/7csmg90fuqruv?rj-ttl=5&rj-tok=AAABhd0MyqEAxV3qy78UI1Klww',
      description: 'Stasiun radio rock terbaik di Bali.',
      type: 'radio' as const
    }],
    other: [{
      id: 'rri-pro1',
      title: 'RRI Pro 1',
      frequency: 'National',
      genre: 'Information & Entertainment',
      thumbnail: 'https://images.unsplash.com/photo-1593697821252-0c9137d9fc45?q=80&w=300&auto=format&fit=crop',
      url: 'https://stream.radiojar.com/4ywdgup5q1zuv',
      description: 'Radio Republik Indonesia Pro 1 - siaran nasional resmi Indonesia.',
      type: 'radio' as const
    }]
  };
  const currentStations = radioStations[activeRegion as keyof typeof radioStations] || [];
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.05
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };
  const handleShare = (station: any) => {
    const text = `Dengarkan ${station.title} (${station.frequency}) di Nusantara Stream!`;
    const url = window.location.href;
    try {
      navigator.clipboard.writeText(`${text} ${url}`);
      alert('Link copied to clipboard');
    } catch (err) {
      console.error('Failed to copy', err);
    }
  };
  return <section className="py-16" data-unique-id="47cbc2ff-d73e-4741-8880-7c3c8415d1bb" data-file-name="components/radio/radio-directory.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="299a8399-680b-4960-b28f-6039c5e38c12" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">
        {/* Region selector */}
        <div className="mb-10 overflow-x-auto scrollbar-hide" data-unique-id="59b5666b-43f7-4038-aa95-891fb6ae216f" data-file-name="components/radio/radio-directory.tsx">
          <div className="flex gap-2 min-w-max" data-unique-id="21344a7d-b191-4922-8cc7-eec2beb2cb87" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">
            {regions.map(region => <button key={region.id} onClick={() => setActiveRegion(region.id)} className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${activeRegion === region.id ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground hover:bg-accent/80'}`} data-unique-id="a0a23009-70ed-46f4-b4c0-a60c179d121e" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">
                {region.name}
              </button>)}
          </div>
        </div>
        
        {/* Radio stations grid */}
        <motion.div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6" variants={containerVariants} initial="hidden" animate="visible" key={activeRegion} // Force re-animation when region changes
      data-unique-id="afc9c171-c5e0-4b61-927e-66a5f1020542" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">
          {currentStations.map(station => <motion.div key={station.id} variants={itemVariants} className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow" data-unique-id="1968908a-df6a-4bae-a3b1-920534c8b195" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">
              <div className="relative h-48" data-unique-id="02881e63-77e7-4c36-8c78-25d069666a2a" data-file-name="components/radio/radio-directory.tsx">
                <img src={station.thumbnail} alt={station.title} className="w-full h-full object-cover" data-unique-id="37a2ea31-f063-402a-a250-ebb1181628bd" data-file-name="components/radio/radio-directory.tsx" />
                
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/70 to-transparent text-white" data-unique-id="3f82eade-51f1-453b-84a6-9a84c79ede24" data-file-name="components/radio/radio-directory.tsx">
                  <div className="flex justify-between items-end" data-unique-id="c08f723d-e67e-4ed8-a28b-ebdde2a4c75e" data-file-name="components/radio/radio-directory.tsx">
                    <div data-unique-id="7873fd9a-dfed-4165-8c12-d3d89bcda68d" data-file-name="components/radio/radio-directory.tsx">
                      <h3 className="font-medium" data-unique-id="84790752-22a0-41fd-92fa-4757bed16ef8" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">{station.title}</h3>
                      <p className="text-sm text-white/80" data-unique-id="1cb6d1f1-b31f-4654-9811-2d825cf27e87" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">{station.frequency}</p>
                    </div>
                    
                    <button onClick={() => play(station)} className="h-10 w-10 rounded-full bg-primary flex items-center justify-center hover:scale-105 transition-transform" data-unique-id="15137336-0180-4666-b556-1b702198a376" data-file-name="components/radio/radio-directory.tsx">
                      <Play className="h-5 w-5 text-primary-foreground" />
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="p-4 flex justify-between items-center" data-unique-id="cf75859a-55ea-4a1f-9bb7-a7de1e56b21f" data-file-name="components/radio/radio-directory.tsx">
                <div data-unique-id="32088549-08f9-4ed4-97f6-a3f8d0232c0d" data-file-name="components/radio/radio-directory.tsx">
                  <p className="text-sm text-muted-foreground" data-unique-id="cd0cf745-caa5-46a2-be17-162506a1c201" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">{station.genre}</p>
                </div>
                
                <div className="flex gap-2" data-unique-id="a906c0c0-70a7-4081-bcf6-f8acf08bd719" data-file-name="components/radio/radio-directory.tsx">
                  <button onClick={() => setShowInfo(showInfo === station.id ? null : station.id)} className="p-2 hover:bg-accent rounded-full transition-colors" data-unique-id="9828e1ae-b2a3-4305-bc3a-22ecdca61e38" data-file-name="components/radio/radio-directory.tsx">
                    <Info className="h-4 w-4" />
                  </button>
                  
                  <button onClick={() => handleShare(station)} className="p-2 hover:bg-accent rounded-full transition-colors" data-unique-id="d77e9b25-7f76-441b-b79e-5b7aa89fc055" data-file-name="components/radio/radio-directory.tsx">
                    <Share2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
              
              {/* Station info panel */}
              {showInfo === station.id && <motion.div initial={{
            height: 0,
            opacity: 0
          }} animate={{
            height: 'auto',
            opacity: 1
          }} className="px-4 pb-4 border-t border-border" data-unique-id="aec50108-d682-4927-86fd-644f2e697a57" data-file-name="components/radio/radio-directory.tsx">
                  <p className="text-sm text-muted-foreground py-3" data-unique-id="4626308d-1fd9-4197-81ed-121339bc8d84" data-file-name="components/radio/radio-directory.tsx" data-dynamic-text="true">{station.description}</p>
                </motion.div>}
            </motion.div>)}
        </motion.div>
      </div>
    </section>;
}