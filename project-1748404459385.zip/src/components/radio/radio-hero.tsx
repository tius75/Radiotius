'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Radio, Search } from 'lucide-react';
export default function RadioHero() {
  return <section className="relative py-16 bg-muted/50 overflow-hidden" data-unique-id="9f476dee-c728-489f-b824-94146a394107" data-file-name="components/radio/radio-hero.tsx" data-dynamic-text="true">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10 overflow-hidden" data-unique-id="a818e541-2403-4eae-9f01-0d1dc9e2023a" data-file-name="components/radio/radio-hero.tsx">
        <div className="absolute top-1/2 right-1/4 w-[500px] h-[500px] rounded-full bg-chart-1/5 blur-3xl" data-unique-id="4635874f-5a4f-463a-a64e-24d6dcd9c05b" data-file-name="components/radio/radio-hero.tsx" />
      </div>
      
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="67a5913d-9b02-4f67-9c9b-5083de5fa14a" data-file-name="components/radio/radio-hero.tsx">
        <div className="max-w-3xl" data-unique-id="ae391b07-cac9-4562-916d-8ec7ad606d26" data-file-name="components/radio/radio-hero.tsx">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5
        }} data-unique-id="0da29627-3d4e-40a7-b139-93aa474c1608" data-file-name="components/radio/radio-hero.tsx">
            <div className="inline-flex items-center gap-2 bg-accent px-4 py-1.5 rounded-full text-sm font-medium mb-4" data-unique-id="bc565365-12c1-4036-8205-f37118dd3eec" data-file-name="components/radio/radio-hero.tsx">
              <Radio className="h-4 w-4 text-chart-1" />
              <span data-unique-id="9242786e-c87f-4ce0-ae35-46e5176a9cb0" data-file-name="components/radio/radio-hero.tsx"><span className="editable-text" data-unique-id="a3bd5099-8e93-494b-a8c6-3f293a1985c6" data-file-name="components/radio/radio-hero.tsx">Radio Streaming</span></span>
            </div>
            
            <h1 className="text-4xl font-bold mb-4" data-unique-id="14913086-0b7a-4960-97ca-7cca49895d4b" data-file-name="components/radio/radio-hero.tsx"><span className="editable-text" data-unique-id="93bd9baf-665b-41e7-9111-4d36661ec3fa" data-file-name="components/radio/radio-hero.tsx">
              Radio Indonesia
              </span><span className="bg-gradient-to-r from-chart-1 to-chart-2 bg-clip-text text-transparent" data-unique-id="069e89bd-1aa3-4212-ac18-8733d7ed3153" data-file-name="components/radio/radio-hero.tsx"><span className="editable-text" data-unique-id="3d04c122-dd8f-41d0-b9a4-6f742c99b0f7" data-file-name="components/radio/radio-hero.tsx"> Terlengkap</span></span>
            </h1>
            
            <p className="text-muted-foreground text-lg mb-8" data-unique-id="a79e59e7-7d8d-44b5-aaef-888c7435ce26" data-file-name="components/radio/radio-hero.tsx"><span className="editable-text" data-unique-id="aee08ddb-67e5-4f69-81eb-2675f0df50b9" data-file-name="components/radio/radio-hero.tsx">
              Temukan dan dengarkan lebih dari 100 stasiun radio dari seluruh Indonesia. 
              Dari Sabang sampai Merauke, semua ada di sini.
            </span></p>
          </motion.div>
          
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5,
          delay: 0.2
        }} className="relative" data-unique-id="0fa59b03-ee8e-41d9-9327-93ae9bb7a183" data-file-name="components/radio/radio-hero.tsx">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none" data-unique-id="944fbfbb-6b23-4d6e-85c9-6efe3a45acc5" data-file-name="components/radio/radio-hero.tsx">
              <Search className="h-5 w-5 text-muted-foreground" />
            </div>
            <input type="text" placeholder="Cari radio favorit Anda..." className="w-full px-10 py-3 bg-card border border-border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/30" data-unique-id="95d81c44-0823-4e97-a4d5-3259fcab1318" data-file-name="components/radio/radio-hero.tsx" />
          </motion.div>
        </div>
      </div>
    </section>;
}