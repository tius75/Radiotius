'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Headphones, SearchIcon } from 'lucide-react';
export default function PodcastHero() {
  return <section className="py-16 bg-gradient-to-br from-background to-accent/30" data-unique-id="14759e19-a0a7-47f5-b93e-bda6bd4cda30" data-file-name="components/podcast/podcast-hero.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="f6a169cc-3f19-42b8-b7eb-0b452baff4b2" data-file-name="components/podcast/podcast-hero.tsx">
        <div className="text-center max-w-3xl mx-auto" data-unique-id="cdcd374b-ee03-4bd2-b091-767ff8faaf87" data-file-name="components/podcast/podcast-hero.tsx">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5
        }} data-unique-id="c9114840-8982-4f9b-8304-2dc51a412ef3" data-file-name="components/podcast/podcast-hero.tsx">
            <div className="inline-flex items-center gap-2 bg-accent px-4 py-1.5 rounded-full text-sm font-medium mb-4" data-unique-id="7b42e343-1bf5-4be1-ac76-11bc667d8c31" data-file-name="components/podcast/podcast-hero.tsx">
              <Headphones className="h-4 w-4 text-chart-3" />
              <span data-unique-id="1275a3d2-b575-4bc4-a114-1e51da64e37b" data-file-name="components/podcast/podcast-hero.tsx"><span className="editable-text" data-unique-id="60fae1f9-86fb-4606-a09e-ac209c0119b5" data-file-name="components/podcast/podcast-hero.tsx">Podcast Player</span></span>
            </div>
            
            <h1 className="text-4xl font-bold mb-6" data-unique-id="ff296c53-26b5-4fb4-9f3a-20aec7a3445c" data-file-name="components/podcast/podcast-hero.tsx"><span className="editable-text" data-unique-id="8ea6d4a6-2e73-4678-84e9-598a5a6fb8e8" data-file-name="components/podcast/podcast-hero.tsx">
              Podcast
              </span><span className="bg-gradient-to-r from-chart-3 to-chart-4 bg-clip-text text-transparent" data-unique-id="73a75de9-8903-48b5-a048-f4420c99608b" data-file-name="components/podcast/podcast-hero.tsx"><span className="editable-text" data-unique-id="2efc2a0a-322a-433a-a506-89985d84bcfe" data-file-name="components/podcast/podcast-hero.tsx"> Indonesia</span></span><span className="editable-text" data-unique-id="89b7d1b8-10bf-4deb-a3b5-e50b329487bc" data-file-name="components/podcast/podcast-hero.tsx"> Terbaik
            </span></h1>
            
            <p className="text-muted-foreground text-lg mb-8 max-w-2xl mx-auto" data-unique-id="a6e5a147-dcbc-4527-b870-48624b143613" data-file-name="components/podcast/podcast-hero.tsx"><span className="editable-text" data-unique-id="157f1008-b360-4900-8b8e-6fed537f0371" data-file-name="components/podcast/podcast-hero.tsx">
              Temukan dan dengarkan berbagai podcast menarik dari kreator Indonesia. 
              Dari topik bisnis, komedi, hingga cerita misteri.
            </span></p>
          </motion.div>
          
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5,
          delay: 0.2
        }} className="relative max-w-md mx-auto" data-unique-id="f1f3c193-904b-42cb-a024-63ef682c7824" data-file-name="components/podcast/podcast-hero.tsx">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none" data-unique-id="fc250ceb-a873-4dc0-bfce-e64c7e5f9137" data-file-name="components/podcast/podcast-hero.tsx">
              <SearchIcon className="h-5 w-5 text-muted-foreground" />
            </div>
            <input type="text" placeholder="Cari podcast favorit..." className="w-full px-10 py-3 bg-card border border-border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/30" data-unique-id="ad024428-734a-4588-962c-8d0b98672911" data-file-name="components/podcast/podcast-hero.tsx" />
          </motion.div>
        </div>
      </div>
    </section>;
}