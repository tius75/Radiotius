'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Play, Share2 } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function PodcastList() {
  const {
    play
  } = usePlayerStore();
  const categories = [{
    id: 'all',
    name: 'Semua'
  }, {
    id: 'comedy',
    name: 'Komedi'
  }, {
    id: 'business',
    name: 'Bisnis'
  }, {
    id: 'education',
    name: 'Edukasi'
  }, {
    id: 'stories',
    name: 'Cerita'
  }];
  const [activeCategory, setActiveCategory] = React.useState('all');
  const podcastEpisodes = [{
    id: 'kejartech-1',
    title: 'Karir di Dunia Tech Indonesia',
    category: 'business',
    host: 'Kejar Tech',
    thumbnail: 'https://images.unsplash.com/photo-1581092583537-20d51b4b4f1b?q=80&w=300&auto=format&fit=crop',
    description: 'Membahas berbagai karir di industri teknologi Indonesia dan tips untuk memulainya.',
    duration: 2902,
    // 48:22 in seconds
    date: '12 Mei 2023',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }, {
    id: 'komedi-santuy',
    title: 'Cerita Kocak Masa Sekolah',
    category: 'comedy',
    host: 'Komedi Santuy',
    thumbnail: "https://picsum.photos/200",
    description: 'Mengenang masa-masa sekolah dengan cerita lucu dan konyol.',
    duration: 3734,
    // 62:14 in seconds
    date: '5 Juni 2023',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }, {
    id: 'edukasi-1',
    title: 'Psikologi dalam Kehidupan Sehari-hari',
    category: 'education',
    host: 'Psikologi Praktis',
    thumbnail: 'https://images.unsplash.com/photo-1535957998253-26ae1ef29506?q=80&w=300&auto=format&fit=crop',
    description: 'Belajar tentang psikologi dasar dan aplikasinya dalam kehidupan kita.',
    duration: 2737,
    // 45:37 in seconds
    date: '28 April 2023',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }, {
    id: 'cerita-horor',
    title: 'Kisah Misteri Dari Desa Terpencil',
    category: 'stories',
    host: 'KIKIS',
    thumbnail: 'https://images.unsplash.com/photo-1616587894289-86480e533129?q=80&w=300&auto=format&fit=crop',
    description: 'Cerita horor dan misteri dari berbagai daerah di Indonesia.',
    duration: 4390,
    // 73:10 in seconds
    date: '19 Maret 2023',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }, {
    id: 'properti-bisnis',
    title: 'Investasi Properti untuk Pemula',
    category: 'business',
    host: 'Bisnis Properti',
    thumbnail: 'https://images.unsplash.com/photo-1560520653-9e0e4c89eb11?q=80&w=300&auto=format&fit=crop',
    description: 'Panduan lengkap untuk memulai investasi di dunia properti.',
    duration: 3348,
    // 55:48 in seconds
    date: '2 Februari 2023',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }, {
    id: 'komedi-habis',
    title: 'Stand Up Comedy Special',
    category: 'comedy',
    host: 'Majelis Lucu Indonesia',
    thumbnail: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=300&auto=format&fit=crop',
    description: 'Kumpulan stand up comedy terbaik dari komika Indonesia.',
    duration: 5242,
    // 87:22 in seconds
    date: '15 Januari 2023',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }];
  const filteredPodcasts = activeCategory === 'all' ? podcastEpisodes : podcastEpisodes.filter(podcast => podcast.category === activeCategory);
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.05
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };
  return <section className="py-16 bg-muted/50" data-unique-id="7d4aee3a-daf3-4d3f-9ee7-5f0790e59dc0" data-file-name="components/podcast/podcast-list.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="a7c0fb06-2897-45fb-a6f9-a710c6842b52" data-file-name="components/podcast/podcast-list.tsx">
        <div className="mb-10" data-unique-id="402d7af0-45ba-44f8-aa63-ac6d38af5b30" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">
          <h2 className="text-2xl font-semibold mb-6" data-unique-id="8d89aa77-bb76-4bc9-945f-e2ce4ec0a972" data-file-name="components/podcast/podcast-list.tsx"><span className="editable-text" data-unique-id="c6a76df5-798e-4c26-ba4e-fc8167c58d67" data-file-name="components/podcast/podcast-list.tsx">Episode Terbaru</span></h2>
          
          {/* Category selector */}
          <div className="flex gap-2 overflow-x-auto pb-2" data-unique-id="b61e8f8c-0bcb-478f-9489-00cab5060599" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">
            {categories.map(category => <button key={category.id} onClick={() => setActiveCategory(category.id)} className={`px-5 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${activeCategory === category.id ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground hover:bg-accent/80'}`} data-unique-id="da89d962-85de-45b1-9b7b-c6f94f7c1322" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">
                {category.name}
              </button>)}
          </div>
        </div>
        
        <motion.div className="space-y-4" variants={containerVariants} initial="hidden" animate="visible" key={activeCategory} data-unique-id="b14ef155-f084-40b7-ab04-d8b456992051" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">
          {filteredPodcasts.map(podcast => <motion.div key={podcast.id} variants={itemVariants} className="bg-card border border-border rounded-xl p-4 hover:shadow-md transition-shadow" data-unique-id="fc783a7e-412b-4995-9f07-3849621498a7" data-file-name="components/podcast/podcast-list.tsx">
              <div className="flex flex-col md:flex-row gap-4" data-unique-id="88e7047a-aa03-4689-89a2-50d9adbcd0a5" data-file-name="components/podcast/podcast-list.tsx">
                <div className="w-full md:w-48 h-48 rounded-lg overflow-hidden flex-shrink-0" data-unique-id="4e696462-9267-4568-919c-89ad820409fd" data-file-name="components/podcast/podcast-list.tsx">
                  <img src={podcast.thumbnail} alt={podcast.title} className="w-full h-full object-cover" data-unique-id="11f1acee-b7ec-4838-840d-798fc2e9fe95" data-file-name="components/podcast/podcast-list.tsx" />
                </div>
                
                <div className="flex-grow flex flex-col" data-unique-id="5990d7ee-8848-4b46-8032-4e286f07f902" data-file-name="components/podcast/podcast-list.tsx">
                  <div className="flex-grow" data-unique-id="3fc39e82-ee80-415e-8e58-dbaad537da79" data-file-name="components/podcast/podcast-list.tsx">
                    <div className="flex justify-between items-start" data-unique-id="66ce903d-9e04-430a-9de9-1291f9c13b17" data-file-name="components/podcast/podcast-list.tsx">
                      <div data-unique-id="7f884ed1-c06f-4fd2-bdd1-3de5491bb7a6" data-file-name="components/podcast/podcast-list.tsx">
                        <h3 className="text-lg font-medium mb-1" data-unique-id="5814f6c4-8cb3-4521-9d3d-9a676e7688b9" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">{podcast.title}</h3>
                        <p className="text-muted-foreground" data-unique-id="b0e7dff1-1a1c-48fb-a82b-284efd9c1526" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">{podcast.host}</p>
                      </div>
                      
                      <button onClick={() => {
                    const text = `Check out this podcast: ${podcast.title} by ${podcast.host}`;
                    const url = window.location.href;
                    navigator.clipboard.writeText(`${text} ${url}`);
                    alert('Link copied to clipboard');
                  }} className="p-2 text-muted-foreground hover:text-foreground" data-unique-id="2b7bad48-f4c2-4782-ac7b-a5f609b653c1" data-file-name="components/podcast/podcast-list.tsx">
                        <Share2 className="h-4 w-4" />
                      </button>
                    </div>
                    
                    <p className="mt-3 text-sm text-muted-foreground line-clamp-3" data-unique-id="c58bb6d3-97b0-41b2-aa84-c0b70a01beac" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">{podcast.description}</p>
                  </div>
                  
                  <div className="flex justify-between items-center mt-4" data-unique-id="eef205f0-88b2-418b-9c09-b4d7624abedc" data-file-name="components/podcast/podcast-list.tsx">
                    <div className="flex items-center gap-4" data-unique-id="3a04421a-4dc2-4b91-832b-976fc6f851fe" data-file-name="components/podcast/podcast-list.tsx">
                      <span className="text-sm text-muted-foreground" data-unique-id="8a110f5f-be29-4316-bbb1-1c048d0f3cd7" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">{podcast.duration}</span>
                      <span className="text-sm text-muted-foreground" data-unique-id="3fdba599-bb4a-4e1b-8647-ab7f59db6f59" data-file-name="components/podcast/podcast-list.tsx" data-dynamic-text="true">{podcast.date}</span>
                    </div>
                    
                    <button onClick={() => play(podcast)} className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-full text-sm hover:opacity-90 transition-opacity" data-unique-id="a1e50333-44ae-4f5d-a7dc-8797bcba0a76" data-file-name="components/podcast/podcast-list.tsx">
                      <Play className="h-4 w-4" />
                      <span data-unique-id="8f643c50-6980-40ea-a171-62ee17f909e5" data-file-name="components/podcast/podcast-list.tsx"><span className="editable-text" data-unique-id="44a8d9e7-3848-4a37-a57a-d73b86cbad5c" data-file-name="components/podcast/podcast-list.tsx">Play</span></span>
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>)}
        </motion.div>
      </div>
    </section>;
}