'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { PlayCircle, Mic } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function PopularPodcasts() {
  const {
    play
  } = usePlayerStore();
  const featuredPodcasts = [{
    id: 'ceritasilanghariini',
    title: 'Cerita Silang Hari Ini',
    host: 'Iqbal Hariadi',
    thumbnail: "https://picsum.photos/200",
    description: 'Podcast seputar cerita kehidupan sehari-hari dengan sudut pandang yang berbeda.',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }, {
    id: 'podcastancur',
    title: 'Podcast Ancur',
    host: 'Gofar Hilman',
    thumbnail: "https://picsum.photos/200",
    description: 'Percakapan santai namun bermakna dengan berbagai topik menarik.',
    url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
    type: 'podcast' as const
  }];
  return <section className="py-16" data-unique-id="9f759a44-5ede-490d-9a7b-b78eeea3006c" data-file-name="components/podcast/popular-podcasts.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="0b121c82-b150-4948-8664-b3057576107f" data-file-name="components/podcast/popular-podcasts.tsx">
        <div className="mb-10" data-unique-id="2a467f7c-d2bb-4cee-a01c-00bd345def72" data-file-name="components/podcast/popular-podcasts.tsx">
          <div className="flex items-center gap-2 mb-2" data-unique-id="09fe8955-a9d0-4587-9dfb-5a20a354932b" data-file-name="components/podcast/popular-podcasts.tsx">
            <Mic className="h-5 w-5 text-chart-3" />
            <h2 className="text-2xl font-semibold" data-unique-id="a41ed443-2ec1-40d7-9d72-ed194c2ed95f" data-file-name="components/podcast/popular-podcasts.tsx"><span className="editable-text" data-unique-id="f62ad398-1ad0-43a4-9477-dee08c862114" data-file-name="components/podcast/popular-podcasts.tsx">Featured Podcasts</span></h2>
          </div>
          <p className="text-muted-foreground" data-unique-id="cb20e7d9-b047-471c-ae5b-b7c82ff075d0" data-file-name="components/podcast/popular-podcasts.tsx"><span className="editable-text" data-unique-id="80b3ad16-fa8b-4106-8c62-72092727cb97" data-file-name="components/podcast/popular-podcasts.tsx">Podcast pilihan minggu ini yang direkomendasikan untuk Anda</span></p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8" data-unique-id="a5981947-aaa8-426e-83e3-4e3ab32856d3" data-file-name="components/podcast/popular-podcasts.tsx" data-dynamic-text="true">
          {featuredPodcasts.map(podcast => <motion.div key={podcast.id} initial={{
          opacity: 0,
          y: 20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} viewport={{
          once: true
        }} transition={{
          duration: 0.5
        }} className="group relative rounded-2xl overflow-hidden h-80" data-unique-id="9df5c7e4-5304-44d8-bd50-e2f5232fb044" data-file-name="components/podcast/popular-podcasts.tsx">
              <img src={podcast.thumbnail} alt={podcast.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" data-unique-id="dab9dd20-d91d-479c-afcf-922dd0056dc4" data-file-name="components/podcast/popular-podcasts.tsx" />
              
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-90" data-unique-id="c21e9745-8dae-4431-9a86-be00dfa30c14" data-file-name="components/podcast/popular-podcasts.tsx">
                <div className="absolute bottom-0 left-0 right-0 p-6 text-white" data-unique-id="a152a84a-5cf4-4371-9f0c-99c02e162cb5" data-file-name="components/podcast/popular-podcasts.tsx">
                  <div className="flex justify-between items-end mb-4" data-unique-id="f1978599-0ab3-4908-8829-6871fe6e12f5" data-file-name="components/podcast/popular-podcasts.tsx">
                    <div data-unique-id="9699e105-da8d-4646-af8d-8fbf08c5b7e8" data-file-name="components/podcast/popular-podcasts.tsx">
                      <h3 className="text-xl font-medium mb-1" data-unique-id="2a450ce2-6791-4c8c-908e-200354b74cb1" data-file-name="components/podcast/popular-podcasts.tsx" data-dynamic-text="true">{podcast.title}</h3>
                      <p className="text-white/80" data-unique-id="51a8fb69-c909-45de-a148-ec8d69101382" data-file-name="components/podcast/popular-podcasts.tsx" data-dynamic-text="true"><span className="editable-text" data-unique-id="636464df-0519-4bb9-9c21-ee7906b6e99d" data-file-name="components/podcast/popular-podcasts.tsx">oleh </span>{podcast.host}</p>
                    </div>
                    
                    <button onClick={() => play(podcast)} className="h-12 w-12 rounded-full bg-primary flex items-center justify-center hover:scale-105 transition-transform" data-unique-id="92e14d8c-85c2-439d-9f35-cefcc543d324" data-file-name="components/podcast/popular-podcasts.tsx">
                      <PlayCircle className="h-6 w-6 text-primary-foreground" />
                    </button>
                  </div>
                  
                  <p className="text-sm text-white/70" data-unique-id="a134451e-2fb0-497e-b874-00ac2e9c0404" data-file-name="components/podcast/popular-podcasts.tsx" data-dynamic-text="true">{podcast.description}</p>
                </div>
              </div>
            </motion.div>)}
        </div>
      </div>
    </section>;
}