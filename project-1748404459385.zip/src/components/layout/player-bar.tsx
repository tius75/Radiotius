'use client';

import React, { useEffect, useRef } from 'react';
import { usePlayerStore, MediaType } from '@/lib/store/use-player-store';
import { cn } from '@/lib/utils';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Share2, Facebook, Instagram, Music, Radio, Tv, Headphones } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
export default function PlayerBar() {
  const {
    currentTrack,
    isPlaying,
    volume,
    play,
    pause,
    setVolume,
    next,
    previous
  } = usePlayerStore();
  const [showShareMenu, setShowShareMenu] = React.useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  useEffect(() => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.play().catch(err => {
          console.error("Playback failed:", err);
          pause();
        });
      } else {
        audioRef.current.pause();
      }
    }
  }, [isPlaying, currentTrack, pause]);
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);
  const handleShare = (platform: string) => {
    if (!currentTrack) return;
    const text = `Check out ${currentTrack.title}${currentTrack.artist ? ` by ${currentTrack.artist}` : ''} on Nusantara Stream!`;
    const url = window.location.href;
    switch (platform) {
      case 'whatsapp':
        window.open(`https://wa.me/?text=${encodeURIComponent(text + ' ' + url)}`, '_blank');
        break;
      case 'facebook':
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}&quote=${encodeURIComponent(text)}`, '_blank');
        break;
      case 'instagram':
        // Instagram doesn't support direct sharing via URL, but we'll add it for completeness
        alert('Copy link and share on Instagram: ' + url);
        break;
      default:
        navigator.clipboard.writeText(text + ' ' + url);
        alert('Link copied to clipboard');
    }
    setShowShareMenu(false);
  };
  if (!currentTrack) {
    return null; // Don't show player bar if nothing is playing
  }
  const getMediaIcon = (type: MediaType) => {
    switch (type) {
      case 'radio':
        return <Radio className="h-4 w-4" />;
      case 'tv':
        return <Tv className="h-4 w-4" />;
      case 'podcast':
        return <Headphones className="h-4 w-4" />;
      case 'music':
        return <Music className="h-4 w-4" />;
      default:
        return <Music className="h-4 w-4" />;
    }
  };
  return <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border z-50" data-unique-id="4beb4066-bf15-4ac0-9eb9-8f97931fe2bc" data-file-name="components/layout/player-bar.tsx">
      <audio ref={audioRef} src={currentTrack.url} autoPlay={isPlaying} onEnded={() => next()} data-unique-id="9de0252e-974b-409a-ad73-d84999ce3430" data-file-name="components/layout/player-bar.tsx" />
      
      <motion.div initial={{
      y: 20,
      opacity: 0
    }} animate={{
      y: 0,
      opacity: 1
    }} className="max-w-screen-2xl mx-auto px-4 py-3 grid grid-cols-3" data-unique-id="2e6de3ed-c0bb-4d2a-a2ae-84af5d059be7" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">
        {/* Left: Track info */}
        <div className="flex items-center gap-3" data-unique-id="48550810-5592-4659-8544-56dc0b5ea6f6" data-file-name="components/layout/player-bar.tsx">
          <div className="relative h-12 w-12 rounded-md overflow-hidden bg-muted flex-shrink-0" data-unique-id="97a925a6-7a5c-49d3-b994-8349cff16adc" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">
            {currentTrack.thumbnail ? <Image src={currentTrack.thumbnail} alt={currentTrack.title} fill className="object-cover" data-unique-id="7e598ac9-16e0-4220-8497-22f9c7245f4f" data-file-name="components/layout/player-bar.tsx" /> : <div className="h-full w-full flex items-center justify-center bg-accent" data-unique-id="95dfcaf6-4511-4f9a-932a-237b0c02234a" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">
                {getMediaIcon(currentTrack.type)}
              </div>}
          </div>
          
          <div className="truncate" data-unique-id="98eee48e-bce8-45db-8f74-1c09912ade12" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">
            <p className="font-medium truncate" data-unique-id="2825704c-72e3-4e54-a52e-db1f4af16a58" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">{currentTrack.title}</p>
            {currentTrack.artist && <p className="text-sm text-muted-foreground truncate" data-unique-id="3ac066c9-53b9-4075-bc92-ed0923cbf561" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">{currentTrack.artist}</p>}
          </div>
        </div>
        
        {/* Center: Controls */}
        <div className="flex items-center justify-center gap-4" data-unique-id="39bcbfc6-e4ca-4899-a83f-ceaa5732d89c" data-file-name="components/layout/player-bar.tsx">
          <button onClick={() => previous()} className="p-2 text-muted-foreground hover:text-foreground transition-colors" data-unique-id="5272691e-0e38-4221-8fd5-618e5ba79ab6" data-file-name="components/layout/player-bar.tsx">
            <SkipBack className="h-5 w-5" />
          </button>
          
          <button onClick={() => isPlaying ? pause() : play(currentTrack)} className="p-3 bg-primary text-primary-foreground rounded-full hover:scale-105 transition-transform" data-unique-id="18ebfaea-7086-4cf8-bd5b-32b5cfbb66e1" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">
            {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
          </button>
          
          <button onClick={() => next()} className="p-2 text-muted-foreground hover:text-foreground transition-colors" data-unique-id="eb6ad1a4-0e7b-4aa5-aecb-76b322bf64c7" data-file-name="components/layout/player-bar.tsx">
            <SkipForward className="h-5 w-5" />
          </button>
        </div>
        
        {/* Right: Volume & Share */}
        <div className="flex items-center justify-end gap-4" data-unique-id="38262929-7dae-466e-9c85-f83bdbfac953" data-file-name="components/layout/player-bar.tsx">
          <div className="flex items-center gap-2" data-unique-id="c1ec0254-f889-4f40-af2b-5208bef97e75" data-file-name="components/layout/player-bar.tsx">
            <button onClick={() => setVolume(volume > 0 ? 0 : 0.5)} className="text-muted-foreground hover:text-foreground transition-colors" data-unique-id="b9bc5cf4-9d94-4d3e-9c15-0f6833922212" data-file-name="components/layout/player-bar.tsx" data-dynamic-text="true">
              {volume > 0 ? <Volume2 className="h-5 w-5" /> : <VolumeX className="h-5 w-5" />}
            </button>
            
            <input type="range" min="0" max="1" step="0.01" value={volume} onChange={e => setVolume(parseFloat(e.target.value))} className="w-20 h-2 rounded-full appearance-none bg-accent cursor-pointer" data-unique-id="946f09b2-d057-4d0d-871e-ac91e7620cd2" data-file-name="components/layout/player-bar.tsx" />
          </div>
          
          <div className="relative" data-unique-id="3ab0f58f-ebd7-47ba-8ffe-622e1990d49a" data-file-name="components/layout/player-bar.tsx">
            <button onClick={() => setShowShareMenu(!showShareMenu)} className={cn("p-2 rounded-full transition-colors", showShareMenu ? "bg-accent" : "hover:bg-accent")} data-unique-id="27d60b37-88ef-4f7b-a74d-df95714eb95f" data-file-name="components/layout/player-bar.tsx">
              <Share2 className="h-5 w-5" />
            </button>
            
            <AnimatePresence>
              {showShareMenu && <motion.div initial={{
              opacity: 0,
              y: 10
            }} animate={{
              opacity: 1,
              y: 0
            }} exit={{
              opacity: 0,
              y: 10
            }} className="absolute bottom-full right-0 mb-2 bg-card shadow-lg rounded-md border border-border p-2" data-unique-id="3ea86fc0-9b25-4c0d-8802-04a18ef11155" data-file-name="components/layout/player-bar.tsx">
                  <div className="flex gap-2" data-unique-id="2dbb7723-e92e-40e5-b7c7-a8bb72434d0b" data-file-name="components/layout/player-bar.tsx">
                    <button onClick={() => handleShare('whatsapp')} className="p-2 hover:bg-accent rounded-md transition-colors" aria-label="Share to WhatsApp" data-unique-id="f5c251d5-4330-4758-a58f-09098f9b6424" data-file-name="components/layout/player-bar.tsx">
                      <svg viewBox="0 0 24 24" width="20" height="20" stroke="currentColor" fill="none" data-unique-id="97d2579e-f533-4407-870b-43482dfd85fc" data-file-name="components/layout/player-bar.tsx">
                        <path d="M17.498 14.382c-.301-.15-1.767-.867-2.04-.966-.273-.101-.473-.15-.673.15-.197.295-.771.964-.944 1.162-.175.195-.349.21-.646.075-.3-.15-1.263-.465-2.403-1.485-.888-.795-1.484-1.77-1.66-2.07-.174-.3-.019-.465.13-.615.136-.135.301-.345.451-.523.146-.181.194-.301.297-.496.1-.21.049-.375-.025-.524-.075-.15-.672-1.62-.922-2.206-.24-.584-.487-.51-.672-.51-.172-.015-.371-.015-.571-.015-.2 0-.523.074-.797.359-.273.3-1.045 1.02-1.045 2.475s1.07 2.865 1.219 3.075c.149.195 2.105 3.195 5.1 4.485.714.3 1.27.48 1.704.629.714.227 1.365.195 1.88.121.574-.091 1.767-.721 2.016-1.426.255-.705.255-1.29.18-1.425-.074-.135-.27-.21-.57-.345z" fill="currentColor" strokeLinecap="round" strokeLinejoin="round"></path>
                        <path d="M20.452 3.5h0C18.134 1.195 15.088 0 11.871 0S5.609 1.196 3.29 3.5C.974 5.804-.197 8.849.19 12.066c.137 1.135.425 2.211.823 3.22L0 20l4.833-1.314c.958.375 1.974.608 3.039.608h.003c3.216 0 6.26-1.196 8.579-3.5S20.698 8.85 20.311 5.633c-.137-1.135-.425-2.211-.823-3.22l.964 1.087z" fill="currentColor" stroke="none"></path>
                      </svg>
                    </button>
                    <button onClick={() => handleShare('facebook')} className="p-2 hover:bg-accent rounded-md transition-colors" aria-label="Share to Facebook" data-unique-id="a764bfdd-117d-4851-adfd-36767bc7353c" data-file-name="components/layout/player-bar.tsx">
                      <Facebook className="h-5 w-5" />
                    </button>
                    <button onClick={() => handleShare('instagram')} className="p-2 hover:bg-accent rounded-md transition-colors" aria-label="Share to Instagram" data-unique-id="502a32a7-400a-461a-ba2c-5b4ab48e1bc1" data-file-name="components/layout/player-bar.tsx">
                      <Instagram className="h-5 w-5" />
                    </button>
                  </div>
                </motion.div>}
            </AnimatePresence>
          </div>
        </div>
      </motion.div>
    </div>;
}