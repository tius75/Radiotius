'use client';

import React from 'react';
import Link from 'next/link';
import { cn } from "@/lib/utils";
import { Radio, Tv, Headphones, Music, Menu, X, Home } from 'lucide-react';
import { motion } from 'framer-motion';
import { usePathname } from 'next/navigation';
export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);
  const pathname = usePathname();
  const navItems = [{
    name: 'Home',
    href: '/',
    icon: <Home className="h-5 w-5" />
  }, {
    name: 'Radio',
    href: '/radio',
    icon: <Radio className="h-5 w-5" />
  }, {
    name: 'TV',
    href: '/tv',
    icon: <Tv className="h-5 w-5" />
  }, {
    name: 'Podcast',
    href: '/podcast',
    icon: <Headphones className="h-5 w-5" />
  }, {
    name: 'Music',
    href: '/music',
    icon: <Music className="h-5 w-5" />
  }];
  return <header className="sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b border-border" data-unique-id="31fa82d0-9b31-40cc-89f8-2bd2d8979613" data-file-name="components/layout/navbar.tsx">
      <nav className="max-w-screen-2xl mx-auto px-4 py-3" data-unique-id="4c0dbe5b-fe26-4aee-83fa-8c5b649a53ab" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">
        <div className="flex items-center justify-between" data-unique-id="f4e904d6-3f27-483d-97eb-e1b3efd61cca" data-file-name="components/layout/navbar.tsx">
          <Link href="/" className="flex items-center space-x-2" data-unique-id="5bec743d-5c26-461d-b78f-6652dd9d595d" data-file-name="components/layout/navbar.tsx">
            <motion.div initial={{
            rotate: -10
          }} animate={{
            rotate: 0
          }} transition={{
            duration: 0.5
          }} data-unique-id="adbec9b6-7c32-4a6b-8135-3986e07af48d" data-file-name="components/layout/navbar.tsx">
              <Music className="h-8 w-8 text-primary" />
            </motion.div>
            <span className="text-xl font-bold bg-gradient-to-r from-chart-1 to-chart-2 bg-clip-text text-transparent" data-unique-id="0e818a9d-5e95-4a3f-9c0a-ecda0de05ac6" data-file-name="components/layout/navbar.tsx"><span className="editable-text" data-unique-id="20845222-faae-427c-b954-846adf03adeb" data-file-name="components/layout/navbar.tsx">Nusantara Stream</span></span>
          </Link>
          
          <div className="hidden md:flex items-center gap-6" data-unique-id="698d858d-ea6d-4284-9e9e-d12da31bba84" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">
            {navItems.map(item => <Link key={item.name} href={item.href} className={cn("flex items-center gap-1 text-sm font-medium transition-colors hover:text-primary", pathname === item.href ? "text-primary" : "text-muted-foreground")} data-unique-id="ed95867e-ac58-4de8-a744-ebaeac360c23" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">
                {item.icon}
                <span data-unique-id="a3d27e88-7f4e-4dea-b7ec-6f23439e8413" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">{item.name}</span>
              </Link>)}
          </div>
          
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden p-2 text-foreground" data-unique-id="6ad9ab1f-ab63-4539-9dd0-8997c8ed7adc" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        
        {/* Mobile menu */}
        {isMenuOpen && <motion.div initial={{
        opacity: 0,
        height: 0
      }} animate={{
        opacity: 1,
        height: 'auto'
      }} exit={{
        opacity: 0,
        height: 0
      }} className="md:hidden mt-3 pb-3" data-unique-id="877c7616-9411-4fd6-a6b6-0893c1b0b149" data-file-name="components/layout/navbar.tsx">
            <div className="flex flex-col gap-4" data-unique-id="a40f27f6-3f4d-41be-8385-e273430d767b" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">
              {navItems.map(item => <Link key={item.name} href={item.href} className={cn("flex items-center gap-2 p-2 rounded-md transition-colors", pathname === item.href ? "bg-accent text-primary" : "hover:bg-accent text-muted-foreground")} onClick={() => setIsMenuOpen(false)} data-unique-id="cac18451-eed1-44ed-a68b-78a24fb15522" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">
                  {item.icon}
                  <span data-unique-id="a544919d-22a4-4dc1-9ff6-ccd29e95b7af" data-file-name="components/layout/navbar.tsx" data-dynamic-text="true">{item.name}</span>
                </Link>)}
            </div>
          </motion.div>}
      </nav>
    </header>;
}