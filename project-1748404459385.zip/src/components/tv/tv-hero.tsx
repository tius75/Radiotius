'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { Tv } from 'lucide-react';
export default function TvHero() {
  return <section className="relative py-16 overflow-hidden" data-unique-id="10732b24-85b8-49ce-b075-59859ec789ba" data-file-name="components/tv/tv-hero.tsx">
      <div className="absolute inset-0 -z-10" data-unique-id="6c135056-065f-4bf6-801a-a034558d8bcc" data-file-name="components/tv/tv-hero.tsx">
        <div className="absolute inset-0 bg-muted/50" data-unique-id="0360c302-0e97-4a02-a6a9-b859c8804a3b" data-file-name="components/tv/tv-hero.tsx" />
        <img src="https://images.unsplash.com/photo-1586899028174-e7098604235b?q=80&w=1200&auto=format&fit=crop" alt="TV background" className="w-full h-full object-cover opacity-10" data-unique-id="a416acf6-2396-4a3b-894a-05f995b25c98" data-file-name="components/tv/tv-hero.tsx" />
      </div>
      
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="195e93ba-6036-4153-a754-75667ded6812" data-file-name="components/tv/tv-hero.tsx">
        <div className="max-w-3xl" data-unique-id="a27ce513-f5de-42de-873b-11b82fcdddfd" data-file-name="components/tv/tv-hero.tsx">
          <motion.div initial={{
          opacity: 0,
          y: 20
        }} animate={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5
        }} data-unique-id="76882549-71ae-4a20-8a39-1f9dc74605d9" data-file-name="components/tv/tv-hero.tsx">
            <div className="inline-flex items-center gap-2 bg-accent px-4 py-1.5 rounded-full text-sm font-medium mb-4" data-unique-id="e6ac9873-888a-4aaf-8899-76c92478d99c" data-file-name="components/tv/tv-hero.tsx">
              <Tv className="h-4 w-4 text-chart-2" />
              <span data-unique-id="acaa4e7d-5114-4524-99bc-d4398f498c0f" data-file-name="components/tv/tv-hero.tsx"><span className="editable-text" data-unique-id="efd68e3a-e3ef-48fc-8880-845e9a64f267" data-file-name="components/tv/tv-hero.tsx">Live TV</span></span>
            </div>
            
            <h1 className="text-4xl font-bold mb-4" data-unique-id="190289b4-3afe-43d5-9652-19c26e2128fa" data-file-name="components/tv/tv-hero.tsx"><span className="editable-text" data-unique-id="d22de985-8ae9-4a0d-8378-fc54ccb385e2" data-file-name="components/tv/tv-hero.tsx">
              Streaming TV Indonesia 
              </span><span className="bg-gradient-to-r from-chart-2 to-chart-3 bg-clip-text text-transparent" data-unique-id="c7dabfe0-fa18-43c9-8a06-2e6a00d6858b" data-file-name="components/tv/tv-hero.tsx"><span className="editable-text" data-unique-id="6f5473f5-95ec-4454-8079-61b369f55fdc" data-file-name="components/tv/tv-hero.tsx"> Live</span></span>
            </h1>
            
            <p className="text-muted-foreground text-lg mb-8" data-unique-id="57f74c37-5673-499a-8bb6-4c5cc961d17b" data-file-name="components/tv/tv-hero.tsx"><span className="editable-text" data-unique-id="bbb47688-fec4-4c55-b377-815727a7455a" data-file-name="components/tv/tv-hero.tsx">
              Nikmati siaran langsung dari berbagai channel TV Indonesia dengan kualitas tinggi.
              Streaming tanpa buffering untuk pengalaman menonton terbaik.
            </span></p>
          </motion.div>
        </div>
      </div>
    </section>;
}