'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { PlayCircle, Share2 } from 'lucide-react';
import { usePlayerStore } from '@/lib/store/use-player-store';
export default function TvChannels() {
  const {
    play
  } = usePlayerStore();

  // Categories for TV channels
  const categories = [{
    id: 'national',
    name: 'Nasional'
  }, {
    id: 'news',
    name: 'Berita'
  }, {
    id: 'entertainment',
    name: 'Hiburan'
  }, {
    id: 'local',
    name: 'Lokal'
  }];
  const [activeCategory, setActiveCategory] = React.useState('national');

  // TV channels organized by category
  const tvChannels = {
    national: [{
      id: 'metro-tv',
      title: 'Metro TV',
      logo: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=300&auto=format&fit=crop',
      thumbnail: "https://picsum.photos/200",
      description: 'Stasiun televisi berita 24 jam pertama di Indonesia',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }, {
      id: 'trans-tv',
      title: 'Trans TV',
      logo: "https://picsum.photos/200",
      thumbnail: 'https://images.unsplash.com/photo-1577900232427-18219b9166a0?q=80&w=1200&auto=format&fit=crop',
      description: 'Stasiun televisi hiburan dan keluarga',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }, {
      id: 'rcti',
      title: 'RCTI',
      logo: "https://picsum.photos/200",
      thumbnail: 'https://images.unsplash.com/photo-1562832135-14a35d25edef?q=80&w=1200&auto=format&fit=crop',
      description: 'Rajawali Citra Televisi Indonesia - Stasiun TV hiburan terpopuler',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }, {
      id: 'tvone',
      title: 'tvOne',
      logo: 'https://images.unsplash.com/photo-1628155930542-3c7a64e2c833?q=80&w=300&auto=format&fit=crop',
      thumbnail: "https://picsum.photos/200",
      description: 'Stasiun televisi berita dan olahraga',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }],
    news: [{
      id: 'cnn-indonesia',
      title: 'CNN Indonesia',
      logo: "https://picsum.photos/200",
      thumbnail: 'https://images.unsplash.com/photo-1503694978374-8a2fa686963a?q=80&w=1200&auto=format&fit=crop',
      description: 'Stasiun televisi berita 24 jam dengan standar jurnalisme internasional',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }, {
      id: 'kompas-tv',
      title: 'Kompas TV',
      logo: "https://picsum.photos/200",
      thumbnail: 'https://images.unsplash.com/photo-1522441815192-d9f04eb0615c?q=80&w=1200&auto=format&fit=crop',
      description: 'Stasiun televisi berita dengan slogan "Independen Terpercaya"',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }],
    entertainment: [{
      id: 'net-tv',
      title: 'NET TV',
      logo: 'https://images.unsplash.com/photo-1509281373149-e957c6296406?q=80&w=300&auto=format&fit=crop',
      thumbnail: 'https://images.unsplash.com/photo-1603739903239-8b6e64c3b185?q=80&w=1200&auto=format&fit=crop',
      description: 'Stasiun televisi dengan konten hiburan premium dan program berkualitas',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }, {
      id: 'sctv',
      title: 'SCTV',
      logo: 'https://images.unsplash.com/photo-1554446422-d05db23719d2?q=80&w=300&auto=format&fit=crop',
      thumbnail: "https://picsum.photos/200",
      description: 'Surya Citra Televisi - Stasiun TV hiburan dengan sinetron populer',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }],
    local: [{
      id: 'jtv',
      title: 'JTV Surabaya',
      logo: "https://picsum.photos/200",
      thumbnail: 'https://images.unsplash.com/photo-1530124566582-a618bc2615dc?q=80&w=1200&auto=format&fit=crop',
      description: 'Stasiun televisi lokal Jawa Timur dengan konten budaya dan tradisi',
      url: 'https://sample-videos.com/video321/mp4/720/big_buck_bunny_720p_1mb.mp4',
      type: 'tv' as const
    }]
  };
  const currentChannels = tvChannels[activeCategory as keyof typeof tvChannels] || [];
  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.05
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 20
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.4
      }
    }
  };
  return <section className="py-16" data-unique-id="d69d6904-a71e-4067-b80b-7bbc35918a87" data-file-name="components/tv/tv-channels.tsx">
      <div className="max-w-screen-xl mx-auto px-4 md:px-8" data-unique-id="c1478a44-f802-4e21-9d14-d6452c7706fe" data-file-name="components/tv/tv-channels.tsx" data-dynamic-text="true">
        {/* Category selector */}
        <div className="mb-10 overflow-x-auto" data-unique-id="067baf96-1121-46a4-92d0-1e5e29fc1072" data-file-name="components/tv/tv-channels.tsx">
          <div className="flex gap-2 min-w-max" data-unique-id="89904166-98e3-4ad6-819e-b7b97be4d78d" data-file-name="components/tv/tv-channels.tsx" data-dynamic-text="true">
            {categories.map(category => <button key={category.id} onClick={() => setActiveCategory(category.id)} className={`px-5 py-2 rounded-full text-sm font-medium transition-colors ${activeCategory === category.id ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground hover:bg-accent/80'}`} data-unique-id="bd126b84-b21b-4987-a55f-49e6b615c679" data-file-name="components/tv/tv-channels.tsx" data-dynamic-text="true">
                {category.name}
              </button>)}
          </div>
        </div>
        
        {/* TV channels grid */}
        <motion.div className="grid grid-cols-1 md:grid-cols-2 gap-8" variants={containerVariants} initial="hidden" animate="visible" key={activeCategory} // Force re-animation when category changes
      data-unique-id="6c558804-a830-40d2-b768-e81810143f77" data-file-name="components/tv/tv-channels.tsx" data-dynamic-text="true">
          {currentChannels.map(channel => <motion.div key={channel.id} variants={itemVariants} className="group bg-card border border-border rounded-xl overflow-hidden hover:shadow-md transition-shadow" data-unique-id="6e765607-e356-48b2-8a97-537d9fe64458" data-file-name="components/tv/tv-channels.tsx">
              <div className="relative h-64" data-unique-id="70ba4689-6c52-41c6-9f89-944befa2a1d3" data-file-name="components/tv/tv-channels.tsx">
                <img src={channel.thumbnail} alt={channel.title} className="w-full h-full object-cover" data-unique-id="bd23b767-3868-4591-9b9b-1bfd0b1c6c3b" data-file-name="components/tv/tv-channels.tsx" />
                
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity" data-unique-id="267a0970-a870-4cdc-8eb5-2795415548b9" data-file-name="components/tv/tv-channels.tsx">
                  <button onClick={() => play(channel)} className="p-4 rounded-full bg-primary/90 hover:bg-primary transition-colors" data-unique-id="f84ebe50-cd44-4eec-a06a-d7c57bf67e44" data-file-name="components/tv/tv-channels.tsx">
                    <PlayCircle className="h-10 w-10 text-primary-foreground" />
                  </button>
                </div>
                
                <div className="absolute top-4 left-4" data-unique-id="1a9de5ce-b91e-41e5-9c31-e481be567f90" data-file-name="components/tv/tv-channels.tsx">
                  <div className="h-12 w-12 bg-card rounded-full p-1 shadow-lg" data-unique-id="3cec6e04-7d05-45e9-adfa-b6c1975afe4c" data-file-name="components/tv/tv-channels.tsx">
                    <div className="h-full w-full rounded-full overflow-hidden" data-unique-id="deef93b4-7e12-49b3-bb4d-2e23de58eaab" data-file-name="components/tv/tv-channels.tsx">
                      <img src={channel.logo} alt={`${channel.title} logo`} className="w-full h-full object-cover" data-unique-id="b9c98c81-38b5-46e7-9042-b67b0d0f0d43" data-file-name="components/tv/tv-channels.tsx" />
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="p-4" data-unique-id="b2f3ddc7-246b-45cd-9d4f-de59fcb07194" data-file-name="components/tv/tv-channels.tsx">
                <div className="flex justify-between items-start mb-2" data-unique-id="b967bccf-14ca-41e2-947c-9675974ac44b" data-file-name="components/tv/tv-channels.tsx">
                  <h3 className="font-medium text-lg" data-unique-id="c0b8cd1d-8033-40f1-9b04-aab39678e685" data-file-name="components/tv/tv-channels.tsx" data-dynamic-text="true">{channel.title}</h3>
                  <button onClick={() => {
                const text = `Tonton ${channel.title} di Nusantara Stream!`;
                const url = window.location.href;
                navigator.clipboard.writeText(`${text} ${url}`);
                alert('Link copied to clipboard');
              }} className="p-2 text-muted-foreground hover:text-foreground" data-unique-id="e4ef3724-7a1f-4353-bd5b-9aeabc7db517" data-file-name="components/tv/tv-channels.tsx">
                    <Share2 className="h-4 w-4" />
                  </button>
                </div>
                <p className="text-muted-foreground text-sm" data-unique-id="2071b63b-2606-4620-a0b0-ff263b75b079" data-file-name="components/tv/tv-channels.tsx" data-dynamic-text="true">{channel.description}</p>
              </div>
            </motion.div>)}
        </motion.div>
      </div>
    </section>;
}