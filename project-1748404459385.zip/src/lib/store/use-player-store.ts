'use client';

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type MediaType = 'radio' | 'tv' | 'podcast' | 'music';

interface Track {
  id: string;
  title: string;
  artist?: string;
  thumbnail?: string;
  url: string;
  duration?: number;
  type: MediaType;
}

interface PlaylistType {
  id: string;
  name: string;
  tracks: Track[];
}

interface PlayerState {
  currentTrack: Track | null;
  isPlaying: boolean;
  volume: number;
  playlists: PlaylistType[];
  currentPlaylist: PlaylistType | null;
  queue: Track[];
  
  // Actions
  play: (track: Track) => void;
  pause: () => void;
  setVolume: (volume: number) => void;
  next: () => void;
  previous: () => void;
  addToPlaylist: (playlistId: string, track: Track) => void;
  createPlaylist: (name: string) => void;
  removeFromPlaylist: (playlistId: string, trackId: string) => void;
  addToQueue: (track: Track) => void;
  clearQueue: () => void;
}

export const usePlayerStore = create<PlayerState>()(
  persist(
    (set, get) => ({
      currentTrack: null,
      isPlaying: false,
      volume: 0.8,
      playlists: [],
      currentPlaylist: null,
      queue: [],
      
      // Actions
      play: (track) => set({ currentTrack: track, isPlaying: true }),
      pause: () => set({ isPlaying: false }),
      setVolume: (volume) => set({ volume }),
      
      next: () => {
        const { queue, currentTrack, currentPlaylist } = get();
        
        if (queue.length > 0) {
          const nextTrack = queue[0];
          const newQueue = queue.slice(1);
          set({ currentTrack: nextTrack, queue: newQueue, isPlaying: true });
          return;
        }
        
        if (currentPlaylist && currentTrack) {
          const currentIndex = currentPlaylist.tracks.findIndex(track => track.id === currentTrack.id);
          if (currentIndex < currentPlaylist.tracks.length - 1) {
            const nextTrack = currentPlaylist.tracks[currentIndex + 1];
            set({ currentTrack: nextTrack, isPlaying: true });
          }
        }
      },
      
      previous: () => {
        const { currentTrack, currentPlaylist } = get();
        
        if (currentPlaylist && currentTrack) {
          const currentIndex = currentPlaylist.tracks.findIndex(track => track.id === currentTrack.id);
          if (currentIndex > 0) {
            const prevTrack = currentPlaylist.tracks[currentIndex - 1];
            set({ currentTrack: prevTrack, isPlaying: true });
          }
        }
      },
      
      addToPlaylist: (playlistId, track) => {
        const { playlists } = get();
        const updatedPlaylists = playlists.map(playlist => {
          if (playlist.id === playlistId) {
            // Avoid duplicates
            const exists = playlist.tracks.some(t => t.id === track.id);
            if (!exists) {
              return { ...playlist, tracks: [...playlist.tracks, track] };
            }
          }
          return playlist;
        });
        set({ playlists: updatedPlaylists });
      },
      
      createPlaylist: (name) => {
        const { playlists } = get();
        const newPlaylist = {
          id: crypto.randomUUID(),
          name,
          tracks: []
        };
        set({ playlists: [...playlists, newPlaylist] });
      },
      
      removeFromPlaylist: (playlistId, trackId) => {
        const { playlists } = get();
        const updatedPlaylists = playlists.map(playlist => {
          if (playlist.id === playlistId) {
            return {
              ...playlist,
              tracks: playlist.tracks.filter(track => track.id !== trackId)
            };
          }
          return playlist;
        });
        set({ playlists: updatedPlaylists });
      },
      
      addToQueue: (track) => {
        const { queue } = get();
        set({ queue: [...queue, track] });
      },
      
      clearQueue: () => set({ queue: [] }),
    }),
    {
      name: 'nusantara-stream-storage',
    }
  )
);
